package com.example.util

import com.example.data.model.RoundingMode
import java.text.DecimalFormat
import java.util.Calendar
import kotlin.math.roundToInt
import kotlin.math.roundToLong

object FormatUtils {
    private val currencyFormat = DecimalFormat("#,##0.00")
    private val compactNumberFormat = DecimalFormat("#,##0.##")

    private val thaiMonths = listOf(
        "ม.ค.", "ก.พ.", "มี.ค.", "เม.ย.", "พ.ค.", "มิ.ย.",
        "ก.ค.", "ส.ค.", "ก.ย.", "ต.ค.", "พ.ย.", "ธ.ค."
    )

    private val thaiDays = listOf(
        "อา.", "จ.", "อ.", "พ.", "พฤ.", "ศ.", "ส."
    )

    fun formatBaht(amount: Double): String {
        return "฿${currencyFormat.format(amount)}"
    }

    fun formatNumber(value: Double): String {
        return currencyFormat.format(value)
    }

    fun formatCompact(value: Double): String {
        return compactNumberFormat.format(value)
    }

    fun formatThaiDate(millis: Long): String {
        val cal = Calendar.getInstance().apply { timeInMillis = millis }
        val day = cal.get(Calendar.DAY_OF_MONTH)
        val month = thaiMonths[cal.get(Calendar.MONTH)]
        val buddhistYear = cal.get(Calendar.YEAR) + 543
        return "$day $month $buddhistYear"
    }

    fun formatThaiDayAndDate(millis: Long): String {
        val cal = Calendar.getInstance().apply { timeInMillis = millis }
        val dow = thaiDays[cal.get(Calendar.DAY_OF_WEEK) - 1]
        val day = cal.get(Calendar.DAY_OF_MONTH)
        val month = thaiMonths[cal.get(Calendar.MONTH)]
        return "$dow $day $month"
    }

    fun formatNumericDate(millis: Long): String {
        val cal = Calendar.getInstance().apply { timeInMillis = millis }
        val d = cal.get(Calendar.DAY_OF_MONTH)
        val m = cal.get(Calendar.MONTH) + 1
        val y = cal.get(Calendar.YEAR) + 543
        return "%02d/%02d/%d".format(d, m, y)
    }

    fun startOfDayMillis(millis: Long = System.currentTimeMillis()): Long {
        return Calendar.getInstance().apply {
            timeInMillis = millis
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
    }

    fun startOfCurrentWeekMondayMillis(millis: Long = System.currentTimeMillis()): Long {
        return Calendar.getInstance().apply {
            timeInMillis = startOfDayMillis(millis)
            firstDayOfWeek = Calendar.MONDAY
            val currentDow = get(Calendar.DAY_OF_WEEK)
            val diff = when (currentDow) {
                Calendar.SUNDAY -> -6
                else -> Calendar.MONDAY - currentDow
            }
            add(Calendar.DAY_OF_MONTH, diff)
        }.timeInMillis
    }

    fun addDaysMillis(baseMillis: Long, days: Int): Long {
        return Calendar.getInstance().apply {
            timeInMillis = startOfDayMillis(baseMillis)
            add(Calendar.DAY_OF_MONTH, days)
        }.timeInMillis
    }

    fun roundThaiRetail(rawAmount: Double, mode: RoundingMode): Double {
        if (rawAmount <= 0.0) return 0.0
        return when (mode) {
            RoundingMode.NONE -> (rawAmount * 100.0).roundToLong() / 100.0
            RoundingMode.QUARTER_25 -> (rawAmount * 4.0).roundToLong() / 4.0
            RoundingMode.WHOLE_BAHT -> rawAmount.roundToInt().toDouble()
        }
    }
}
