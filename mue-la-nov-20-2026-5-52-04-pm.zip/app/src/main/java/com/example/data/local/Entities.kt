package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "profiles")
data class ProfileEntity(
    @PrimaryKey val id: String,
    val name: String,
    val colorHex: Long,
    val pin: String,
    val budgetLimit: Double = 700.0,
    val mealsPerDay: Int = 2,
    val isDefaultSeed: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "cart_items")
data class CartItemEntity(
    @PrimaryKey val id: String,
    val profileId: String,
    val name: String,
    val category: String,
    val unit: String,
    val isWeighted: Boolean,
    val weightKg: Double,
    val pricePerKg: Double,
    val roundingMode: String,
    val quantity: Double,
    val unitPrice: Double,
    val isSelected: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
) {
    val lineTotal: Double
        get() = quantity * unitPrice
}

@Entity(tableName = "receipts")
data class ReceiptEntity(
    @PrimaryKey val id: String,
    val profileId: String,
    val storeName: String,
    val purchaseDateMillis: Long,
    val itemsJson: String,
    val subtotal: Double,
    val includeVat: Boolean,
    val vatAmount: Double,
    val discountAmount: Double,
    val discountBeforeVat: Boolean,
    val grandTotal: Double,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "meal_plans")
data class MealPlanEntity(
    @PrimaryKey val id: String,
    val profileId: String,
    val title: String,
    val mealsPerDay: Int,
    val ingredientsJson: String,
    val totalCost: Double,
    val totalMeals: Int,
    val estimatedDays: Double,
    val costPerMeal: Double,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "weekly_active")
data class WeeklyActiveEntity(
    @PrimaryKey val profileId: String,
    val weekStartDateMillis: Long,
    val daysJson: String,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "weekly_history")
data class WeeklyHistoryEntity(
    @PrimaryKey val id: String,
    val profileId: String,
    val weekStartDateMillis: Long,
    val weekEndDateMillis: Long,
    val daysJson: String,
    val totalMealsCount: Int,
    val totalSpent: Double,
    val avgCostPerMeal: Double,
    val createdAt: Long = System.currentTimeMillis()
)
