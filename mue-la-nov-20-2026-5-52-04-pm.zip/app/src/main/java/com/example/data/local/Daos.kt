package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ProfileDao {
    @Query("SELECT * FROM profiles ORDER BY createdAt ASC")
    fun observeProfiles(): Flow<List<ProfileEntity>>

    @Query("SELECT COUNT(*) FROM profiles")
    suspend fun getProfileCount(): Int

    @Query("SELECT * FROM profiles WHERE id = :id LIMIT 1")
    suspend fun getProfileById(id: String): ProfileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProfile(profile: ProfileEntity)

    @Update
    suspend fun updateProfile(profile: ProfileEntity)
}

@Dao
interface CartItemDao {
    @Query("SELECT * FROM cart_items WHERE profileId = :profileId ORDER BY createdAt DESC")
    fun observeCartItems(profileId: String): Flow<List<CartItemEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCartItem(item: CartItemEntity)

    @Update
    suspend fun updateCartItem(item: CartItemEntity)

    @Query("UPDATE cart_items SET isSelected = :selected WHERE profileId = :profileId")
    suspend fun setAllSelected(profileId: String, selected: Boolean)

    @Query("DELETE FROM cart_items WHERE id = :id")
    suspend fun deleteCartItemById(id: String)

    @Query("DELETE FROM cart_items WHERE profileId = :profileId AND isSelected = 1")
    suspend fun deleteSelectedItems(profileId: String)
}

@Dao
interface ReceiptDao {
    @Query("SELECT * FROM receipts WHERE profileId = :profileId ORDER BY purchaseDateMillis DESC, createdAt DESC")
    fun observeReceipts(profileId: String): Flow<List<ReceiptEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReceipt(receipt: ReceiptEntity)

    @Update
    suspend fun updateReceipt(receipt: ReceiptEntity)

    @Query("DELETE FROM receipts WHERE id = :id")
    suspend fun deleteReceiptById(id: String)
}

@Dao
interface MealPlanDao {
    @Query("SELECT * FROM meal_plans WHERE profileId = :profileId ORDER BY createdAt DESC")
    fun observeMealPlans(profileId: String): Flow<List<MealPlanEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMealPlan(plan: MealPlanEntity)

    @Query("DELETE FROM meal_plans WHERE id = :id")
    suspend fun deleteMealPlanById(id: String)
}

@Dao
interface WeeklyDao {
    @Query("SELECT * FROM weekly_active WHERE profileId = :profileId LIMIT 1")
    fun observeWeeklyActive(profileId: String): Flow<WeeklyActiveEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertWeeklyActive(active: WeeklyActiveEntity)

    @Query("SELECT * FROM weekly_history WHERE profileId = :profileId ORDER BY weekStartDateMillis DESC, createdAt DESC")
    fun observeWeeklyHistory(profileId: String): Flow<List<WeeklyHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWeeklyHistory(history: WeeklyHistoryEntity)

    @Query("DELETE FROM weekly_history WHERE id = :id")
    suspend fun deleteWeeklyHistoryById(id: String)
}
