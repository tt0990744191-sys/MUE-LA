package com.example.data.model

import com.squareup.moshi.JsonClass

enum class FoodCategory(val label: String) {
    FRESH_FOOD("อาหารสด"),
    INGREDIENT("วัตถุดิบ"),
    SEASONING("เครื่องปรุง"),
    UTENSIL("เครื่องใช้"),
    HOUSEHOLD("ของใช้"),
    BEVERAGE("เครื่องดื่ม"),
    SNACK("ขนม")
}

enum class FoodUnit(val label: String) {
    KG("กิโลกรัม"),
    GRAM("กรัม"),
    PACK("แพ็ก"),
    PIECE("ชิ้น"),
    BOTTLE("ขวด"),
    BAG("ถุง"),
    TRAY("แผง")
}

enum class RoundingMode(val label: String, val shortLabel: String) {
    NONE("ไม่ปัดเศษ", "แม่นยำ"),
    QUARTER_25("ปัด .00/.25/.50/.75", "ปัด .25"),
    WHOLE_BAHT("ปัดเป็นจำนวนเต็มบาท", "เต็มบาท")
}

enum class MueLaTab(val titleEn: String, val titleTh: String) {
    LIST_FOOD("List Food", "รายการซื้อ"),
    DIGITAL_RECEIPT("Digital", "ออกบิล"),
    RECEIPT("Receipt", "สลิป"),
    MEAL_NOTE("Meal Note", "คำนวณมื้อ"),
    WEEKLY_FOOD("Weekly", "รายสัปดาห์")
}

@JsonClass(generateAdapter = true)
data class ReceiptLineItem(
    val id: String,
    val name: String,
    val category: String,
    val unit: String,
    val quantity: Double,
    val unitPrice: Double,
    val isWeighted: Boolean = false,
    val weightKg: Double = 0.0,
    val pricePerKg: Double = 0.0
) {
    val lineTotal: Double
        get() = quantity * unitPrice
}

@JsonClass(generateAdapter = true)
data class MealIngredient(
    val id: String,
    val name: String,
    val cost: Double,
    val estimatedMeals: Int,
    val sourceReceiptName: String = ""
)

@JsonClass(generateAdapter = true)
data class WeeklyMealEntry(
    val name: String = "",
    val cost: Double = 0.0,
    val mealPlanTitle: String = ""
) {
    val isLogged: Boolean
        get() = name.isNotBlank() || cost > 0.0
}

@JsonClass(generateAdapter = true)
data class WeeklyDayRecord(
    val dayIndex: Int, // 0..6
    val dateMillis: Long,
    val meal1: WeeklyMealEntry = WeeklyMealEntry(),
    val meal2: WeeklyMealEntry = WeeklyMealEntry(),
    val snack: WeeklyMealEntry = WeeklyMealEntry()
) {
    val dayTotal: Double
        get() = meal1.cost + meal2.cost + snack.cost

    val loggedCount: Int
        get() = listOf(meal1, meal2, snack).count { it.isLogged }
}

enum class MealSlotType(val label: String) {
    MEAL_1("มื้อที่ 1"),
    MEAL_2("มื้อที่ 2"),
    SNACK("ของว่าง")
}
