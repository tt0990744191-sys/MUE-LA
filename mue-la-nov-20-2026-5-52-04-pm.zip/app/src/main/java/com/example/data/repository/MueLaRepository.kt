package com.example.data.repository

import com.example.data.local.CartItemDao
import com.example.data.local.CartItemEntity
import com.example.data.local.MealPlanDao
import com.example.data.local.MealPlanEntity
import com.example.data.local.ProfileDao
import com.example.data.local.ProfileEntity
import com.example.data.local.ReceiptDao
import com.example.data.local.ReceiptEntity
import com.example.data.local.WeeklyActiveEntity
import com.example.data.local.WeeklyDao
import com.example.data.local.WeeklyHistoryEntity
import com.example.data.model.MealIngredient
import com.example.data.model.ReceiptLineItem
import com.example.data.model.WeeklyDayRecord
import com.example.util.FormatUtils
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.flow.Flow
import java.util.UUID

class MueLaRepository(
    private val profileDao: ProfileDao,
    private val cartItemDao: CartItemDao,
    private val receiptDao: ReceiptDao,
    private val mealPlanDao: MealPlanDao,
    private val weeklyDao: WeeklyDao
) {
    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val receiptItemsAdapter = moshi.adapter<List<ReceiptLineItem>>(
        Types.newParameterizedType(List::class.java, ReceiptLineItem::class.java)
    )
    private val mealIngredientsAdapter = moshi.adapter<List<MealIngredient>>(
        Types.newParameterizedType(List::class.java, MealIngredient::class.java)
    )
    private val weeklyDaysAdapter = moshi.adapter<List<WeeklyDayRecord>>(
        Types.newParameterizedType(List::class.java, WeeklyDayRecord::class.java)
    )

    fun observeProfiles(): Flow<List<ProfileEntity>> = profileDao.observeProfiles()

    suspend fun ensureDefaultProfileExists() {
        if (profileDao.getProfileCount() == 0) {
            profileDao.insertProfile(
                ProfileEntity(
                    id = "profile_default",
                    name = "โปรไฟล์หลัก",
                    colorHex = 0xFF7D8D39L,
                    pin = "1808",
                    budgetLimit = 700.0,
                    mealsPerDay = 2,
                    isDefaultSeed = true
                )
            )
        }
    }

    suspend fun createProfile(name: String, colorHex: Long, pin: String): ProfileEntity {
        val profile = ProfileEntity(
            id = UUID.randomUUID().toString(),
            name = name.trim(),
            colorHex = colorHex,
            pin = pin,
            budgetLimit = 700.0,
            mealsPerDay = 2,
            isDefaultSeed = false
        )
        profileDao.insertProfile(profile)
        return profile
    }

    suspend fun updateProfile(profile: ProfileEntity) {
        profileDao.updateProfile(profile)
    }

    // Cart
    fun observeCartItems(profileId: String): Flow<List<CartItemEntity>> =
        cartItemDao.observeCartItems(profileId)

    suspend fun insertCartItem(item: CartItemEntity) = cartItemDao.insertCartItem(item)

    suspend fun updateCartItem(item: CartItemEntity) = cartItemDao.updateCartItem(item)

    suspend fun setAllCartItemsSelected(profileId: String, selected: Boolean) =
        cartItemDao.setAllSelected(profileId, selected)

    suspend fun deleteCartItem(id: String) = cartItemDao.deleteCartItemById(id)

    suspend fun deleteSelectedCartItems(profileId: String) =
        cartItemDao.deleteSelectedItems(profileId)

    // Receipts
    fun observeReceipts(profileId: String): Flow<List<ReceiptEntity>> =
        receiptDao.observeReceipts(profileId)

    suspend fun saveReceiptAndClearSelected(receipt: ReceiptEntity) {
        receiptDao.insertReceipt(receipt)
        cartItemDao.deleteSelectedItems(receipt.profileId)
    }

    suspend fun updateReceipt(receipt: ReceiptEntity) = receiptDao.updateReceipt(receipt)

    suspend fun deleteReceipt(id: String) = receiptDao.deleteReceiptById(id)

    // Meal Plans
    fun observeMealPlans(profileId: String): Flow<List<MealPlanEntity>> =
        mealPlanDao.observeMealPlans(profileId)

    suspend fun insertMealPlan(plan: MealPlanEntity) = mealPlanDao.insertMealPlan(plan)

    suspend fun deleteMealPlan(id: String) = mealPlanDao.deleteMealPlanById(id)

    // Weekly
    fun observeWeeklyActive(profileId: String): Flow<WeeklyActiveEntity?> =
        weeklyDao.observeWeeklyActive(profileId)

    suspend fun upsertWeeklyActive(profileId: String, startMillis: Long, days: List<WeeklyDayRecord>) {
        weeklyDao.upsertWeeklyActive(
            WeeklyActiveEntity(
                profileId = profileId,
                weekStartDateMillis = startMillis,
                daysJson = encodeWeeklyDays(days)
            )
        )
    }

    fun observeWeeklyHistory(profileId: String): Flow<List<WeeklyHistoryEntity>> =
        weeklyDao.observeWeeklyHistory(profileId)

    suspend fun saveWeeklyHistory(history: WeeklyHistoryEntity) =
        weeklyDao.insertWeeklyHistory(history)

    suspend fun deleteWeeklyHistory(id: String) =
        weeklyDao.deleteWeeklyHistoryById(id)

    // JSON helpers
    fun encodeReceiptItems(items: List<ReceiptLineItem>): String =
        receiptItemsAdapter.toJson(items)

    fun decodeReceiptItems(json: String): List<ReceiptLineItem> =
        runCatching { receiptItemsAdapter.fromJson(json) }.getOrNull() ?: emptyList()

    fun encodeMealIngredients(items: List<MealIngredient>): String =
        mealIngredientsAdapter.toJson(items)

    fun decodeMealIngredients(json: String): List<MealIngredient> =
        runCatching { mealIngredientsAdapter.fromJson(json) }.getOrNull() ?: emptyList()

    fun encodeWeeklyDays(days: List<WeeklyDayRecord>): String =
        weeklyDaysAdapter.toJson(days)

    fun decodeWeeklyDays(json: String, fallbackStartMillis: Long): List<WeeklyDayRecord> {
        val parsed = runCatching { weeklyDaysAdapter.fromJson(json) }.getOrNull()
        if (!parsed.isNullOrEmpty() && parsed.size == 7) return parsed
        return buildEmptyWeek(fallbackStartMillis)
    }

    fun buildEmptyWeek(startMillis: Long): List<WeeklyDayRecord> {
        val cleanStart = FormatUtils.startOfDayMillis(startMillis)
        return (0..6).map { index ->
            WeeklyDayRecord(
                dayIndex = index,
                dateMillis = FormatUtils.addDaysMillis(cleanStart, index)
            )
        }
    }
}
