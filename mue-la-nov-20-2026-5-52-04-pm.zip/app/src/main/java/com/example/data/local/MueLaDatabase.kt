package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        ProfileEntity::class,
        CartItemEntity::class,
        ReceiptEntity::class,
        MealPlanEntity::class,
        WeeklyActiveEntity::class,
        WeeklyHistoryEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class MueLaDatabase : RoomDatabase() {
    abstract fun profileDao(): ProfileDao
    abstract fun cartItemDao(): CartItemDao
    abstract fun receiptDao(): ReceiptDao
    abstract fun mealPlanDao(): MealPlanDao
    abstract fun weeklyDao(): WeeklyDao

    companion object {
        @Volatile
        private var INSTANCE: MueLaDatabase? = null

        fun getInstance(context: Context): MueLaDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    MueLaDatabase::class.java,
                    "muela_local_db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
