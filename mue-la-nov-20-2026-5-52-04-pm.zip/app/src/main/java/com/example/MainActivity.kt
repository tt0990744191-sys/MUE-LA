package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.local.MueLaDatabase
import com.example.data.model.MueLaTab
import com.example.data.repository.MueLaRepository
import com.example.ui.components.MueLaBottomBar
import com.example.ui.components.MueLaTopBar
import com.example.ui.screens.DigitalReceiptScreen
import com.example.ui.screens.ListFoodScreen
import com.example.ui.screens.MealNoteScreen
import com.example.ui.screens.ProfileLoginScreen
import com.example.ui.screens.ReceiptHistoryScreen
import com.example.ui.screens.WeeklyFoodScreen
import com.example.ui.theme.MintBackground
import com.example.ui.theme.MueLaTheme
import com.example.ui.theme.OliveGreen
import com.example.ui.viewmodel.MueLaUiState
import com.example.ui.viewmodel.MueLaViewModel
import com.example.ui.viewmodel.MueLaViewModelFactory

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val mintArgb = MintBackground.toArgb()
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(mintArgb, mintArgb),
            navigationBarStyle = SystemBarStyle.light(mintArgb, mintArgb)
        )

        val db = MueLaDatabase.getInstance(applicationContext)
        val repository = MueLaRepository(
            profileDao = db.profileDao(),
            cartItemDao = db.cartItemDao(),
            receiptDao = db.receiptDao(),
            mealPlanDao = db.mealPlanDao(),
            weeklyDao = db.weeklyDao()
        )
        val factory = MueLaViewModelFactory(repository)

        setContent {
            MueLaTheme {
                Surface(
                    color = MintBackground,
                    modifier = Modifier.fillMaxSize()
                ) {
                    val viewModel: MueLaViewModel = viewModel(factory = factory)
                    MueLaRootApp(viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
private fun MueLaRootApp(viewModel: MueLaViewModel) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(Unit) {
        viewModel.snackbarEvents.collect { message ->
            snackbarHostState.showSnackbar(message)
        }
    }

    if (!state.isReady) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MintBackground),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator(color = OliveGreen)
        }
        return
    }

    // Snappy Zero-Flicker Fade between Profile Login and Main Workspace
    AnimatedContent(
        targetState = state.activeProfile != null,
        transitionSpec = {
            fadeIn(animationSpec = tween(90)) togetherWith fadeOut(animationSpec = tween(60))
        },
        label = "auth_fade_transition"
    ) { isLoggedIn ->
        if (!isLoggedIn || state.activeProfile == null) {
            ProfileLoginScreen(
                profiles = state.profiles,
                onVerifyPinAndLogin = viewModel::verifyPinAndLogin,
                onCreateProfile = viewModel::createProfile,
                onUpdateProfile = viewModel::updateProfileDetails
            )
        } else {
            MueLaWorkspace(
                state = state,
                viewModel = viewModel,
                snackbarHostState = snackbarHostState
            )
        }
    }
}

@Composable
private fun MueLaWorkspace(
    state: MueLaUiState,
    viewModel: MueLaViewModel,
    snackbarHostState: SnackbarHostState
) {
    val activeProfile = state.activeProfile ?: return
    val selectedCartItems = remember(state.cartItems) {
        state.cartItems.filter { it.isSelected }
    }

    // Back button returns to List Food from any secondary tab
    BackHandler(enabled = state.activeTab != MueLaTab.LIST_FOOD) {
        viewModel.selectTab(MueLaTab.LIST_FOOD)
    }

    Scaffold(
        containerColor = MintBackground,
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            MueLaTopBar(
                activeTab = state.activeTab,
                activeProfile = activeProfile,
                onSwitchProfileClick = viewModel::switchProfileLogout
            )
        },
        bottomBar = {
            MueLaBottomBar(
                activeTab = state.activeTab,
                selectedCartCount = selectedCartItems.size,
                onSelectTab = viewModel::selectTab
            )
        }
    ) { innerPadding ->
        // Snappy Zero-Flicker Fade between the 5 modules
        AnimatedContent(
            targetState = state.activeTab,
            transitionSpec = {
                fadeIn(animationSpec = tween(90)) togetherWith fadeOut(animationSpec = tween(60))
            },
            modifier = Modifier
                .fillMaxSize()
                .background(MintBackground)
                .padding(innerPadding),
            label = "tab_fade_transition"
        ) { tab ->
            when (tab) {
                MueLaTab.LIST_FOOD -> ListFoodScreen(
                    budgetLimit = activeProfile.budgetLimit,
                    cartItems = state.cartItems,
                    onUpdateBudget = viewModel::updateBudgetLimit,
                    onAddCartItem = viewModel::addCartItem,
                    onToggleSelect = viewModel::toggleCartItemSelected,
                    onSetAllSelected = viewModel::setAllCartItemsSelected,
                    onUpdateQtyAndPrice = viewModel::updateCartItemQuantityAndPrice,
                    onDeleteItem = viewModel::deleteCartItem,
                    onIssueReceiptClick = { viewModel.selectTab(MueLaTab.DIGITAL_RECEIPT) }
                )

                MueLaTab.DIGITAL_RECEIPT -> DigitalReceiptScreen(
                    selectedCartItems = selectedCartItems,
                    onGoToListFood = { viewModel.selectTab(MueLaTab.LIST_FOOD) },
                    onSaveReceipt = viewModel::issueDigitalReceipt
                )

                MueLaTab.RECEIPT -> ReceiptHistoryScreen(
                    receipts = state.receipts,
                    onUpdateReceipt = viewModel::updateExistingReceipt,
                    onDeleteReceipt = viewModel::deleteReceipt
                )

                MueLaTab.MEAL_NOTE -> MealNoteScreen(
                    mealsPerDay = activeProfile.mealsPerDay,
                    receipts = state.receipts,
                    workingIngredients = state.workingMealIngredients,
                    useWholeSetMeals = state.useWholeSetMeals,
                    wholeSetMealsCount = state.wholeSetMealsCount,
                    savedMealPlans = state.mealPlans,
                    onUpdateMealsPerDay = viewModel::updateMealsPerDay,
                    onImportFromReceipt = viewModel::importReceiptToMealNote,
                    onAddManualIngredient = viewModel::addManualMealIngredient,
                    onUpdateIngredientMeals = viewModel::updateWorkingIngredientMeals,
                    onRemoveIngredient = viewModel::removeWorkingIngredient,
                    onSetWholeSetMode = viewModel::setWholeSetMode,
                    onSetWholeSetMealsCount = viewModel::setWholeSetMealsCount,
                    onSaveMealPlanSummary = viewModel::saveMealPlanSummary,
                    onDeleteMealPlan = viewModel::deleteMealPlan
                )

                MueLaTab.WEEKLY_FOOD -> WeeklyFoodScreen(
                    weekStartMillis = state.activeWeekStartMillis,
                    weekDays = state.activeWeekDays,
                    mealPlans = state.mealPlans,
                    weeklyHistory = state.weeklyHistory,
                    onChangeWeekStart = viewModel::setWeekStartDate,
                    onLogMealSlot = viewModel::logWeeklyMealSlot,
                    onSaveWeekToHistory = viewModel::saveCurrentWeekToHistory,
                    onDeleteWeeklyHistory = viewModel::deleteWeeklyHistory
                )
            }
        }
    }
}
