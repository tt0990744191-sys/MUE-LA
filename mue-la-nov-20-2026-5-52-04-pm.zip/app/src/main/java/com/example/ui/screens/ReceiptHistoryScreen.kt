package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.local.ReceiptEntity
import com.example.data.model.ReceiptLineItem
import com.example.ui.components.DashedReceiptDivider
import com.example.ui.components.MueLaLogo
import com.example.ui.theme.CharcoalText
import com.example.ui.theme.DeepOlive
import com.example.ui.theme.MintBackground
import com.example.ui.theme.MontserratFontFamily
import com.example.ui.theme.MutedOliveText
import com.example.ui.theme.OliveGreen
import com.example.ui.theme.PromptFontFamily
import com.example.ui.theme.SageBorder
import com.example.ui.theme.SoftOliveBg
import com.example.ui.theme.SoftOrangeBg
import com.example.ui.theme.SurfaceWhite
import com.example.ui.theme.VibrantOrange
import com.example.ui.viewmodel.MueLaViewModel
import com.example.ui.viewmodel.ReceiptUiModel
import com.example.util.FormatUtils

@Composable
fun ReceiptHistoryScreen(
    receipts: List<ReceiptUiModel>,
    onUpdateReceipt: (
        original: ReceiptEntity,
        storeName: String,
        purchaseDateMillis: Long,
        items: List<ReceiptLineItem>,
        includeVat: Boolean,
        discountAmount: Double,
        discountBeforeVat: Boolean
    ) -> Unit,
    onDeleteReceipt: (String) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedReceiptId by remember { mutableStateOf<String?>(null) }

    val filteredReceipts = remember(receipts, searchQuery) {
        val q = searchQuery.trim().lowercase()
        if (q.isEmpty()) receipts
        else receipts.filter { r ->
            val storeMatch = r.entity.storeName.lowercase().contains(q)
            val dateThai = FormatUtils.formatThaiDate(r.entity.purchaseDateMillis).lowercase()
            val dateNum = FormatUtils.formatNumericDate(r.entity.purchaseDateMillis).lowercase()
            storeMatch || dateThai.contains(q) || dateNum.contains(q)
        }
    }

    val activeDetail = remember(receipts, selectedReceiptId) {
        receipts.firstOrNull { it.entity.id == selectedReceiptId }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MintBackground),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 640.dp)
        ) {
            // Search Bar
            Surface(
                color = MintBackground,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = {
                        Text(
                            text = "ค้นหาชื่อร้านค้า หรือ วันที่ (เช่น Makro, พ.ย.)",
                            fontFamily = PromptFontFamily,
                            fontSize = 13.sp
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Filled.Search,
                            contentDescription = "ค้นหาใบเสร็จ",
                            tint = DeepOlive
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(
                                    imageVector = Icons.Filled.Close,
                                    contentDescription = "ล้างคำค้นหา",
                                    tint = MutedOliveText
                                )
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("receipt_search_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = SurfaceWhite,
                        unfocusedContainerColor = SurfaceWhite,
                        focusedBorderColor = OliveGreen,
                        unfocusedBorderColor = SageBorder
                    )
                )
            }

            if (filteredReceipts.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            modifier = Modifier
                                .size(68.dp)
                                .clip(CircleShape)
                                .background(SoftOliveBg),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.History,
                                contentDescription = null,
                                tint = OliveGreen,
                                modifier = Modifier.size(34.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = if (receipts.isEmpty()) "ยังไม่มีประวัติใบเสร็จ" else "ไม่พบใบเสร็จที่ค้นหา",
                            fontFamily = PromptFontFamily,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 16.sp,
                            color = CharcoalText
                        )
                        Text(
                            text = "ใบเสร็จที่บันทึกจากหน้า Digital Receipt จะแสดงที่นี่",
                            fontFamily = PromptFontFamily,
                            fontSize = 13.sp,
                            color = MutedOliveText
                        )
                    }
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(filteredReceipts, key = { it.entity.id }) { receiptUi ->
                        ReceiptSummaryCard(
                            receiptUi = receiptUi,
                            onClick = { selectedReceiptId = receiptUi.entity.id }
                        )
                    }
                    item { Spacer(modifier = Modifier.height(12.dp)) }
                }
            }
        }
    }

    activeDetail?.let { detail ->
        ReceiptDetailDialog(
            receiptUi = detail,
            onDismiss = { selectedReceiptId = null },
            onSaveEdit = { storeName, dateMillis, items, vat, discount, beforeVat ->
                onUpdateReceipt(
                    detail.entity,
                    storeName,
                    dateMillis,
                    items,
                    vat,
                    discount,
                    beforeVat
                )
            },
            onDelete = {
                onDeleteReceipt(detail.entity.id)
                selectedReceiptId = null
            }
        )
    }
}

@Composable
private fun ReceiptSummaryCard(
    receiptUi: ReceiptUiModel,
    onClick: () -> Unit
) {
    val entity = receiptUi.entity
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
        border = BorderStroke(1.dp, SageBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .testTag("receipt_card_${entity.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(SoftOliveBg),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.Storefront,
                        contentDescription = null,
                        tint = DeepOlive,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = entity.storeName,
                        fontFamily = PromptFontFamily,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 16.sp,
                        color = CharcoalText,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${FormatUtils.formatThaiDate(entity.purchaseDateMillis)} · ${receiptUi.items.size} รายการ",
                        fontFamily = PromptFontFamily,
                        fontSize = 12.sp,
                        color = MutedOliveText
                    )
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = FormatUtils.formatBaht(entity.grandTotal),
                    fontFamily = MontserratFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    color = VibrantOrange
                )
                if (entity.includeVat) {
                    Text(
                        text = "รวม VAT 7%",
                        fontFamily = PromptFontFamily,
                        fontSize = 10.sp,
                        color = DeepOlive
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ReceiptDetailDialog(
    receiptUi: ReceiptUiModel,
    onDismiss: () -> Unit,
    onSaveEdit: (
        storeName: String,
        purchaseDateMillis: Long,
        items: List<ReceiptLineItem>,
        includeVat: Boolean,
        discountAmount: Double,
        discountBeforeVat: Boolean
    ) -> Unit,
    onDelete: () -> Unit
) {
    var isEditing by remember(receiptUi) { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var showDatePicker by remember { mutableStateOf(false) }

    var editStore by remember(receiptUi) { mutableStateOf(receiptUi.entity.storeName) }
    var editDateMillis by remember(receiptUi) { mutableLongStateOf(receiptUi.entity.purchaseDateMillis) }
    var editItems by remember(receiptUi) { mutableStateOf(receiptUi.items) }
    var editVat by remember(receiptUi) { mutableStateOf(receiptUi.entity.includeVat) }
    var editDiscountText by remember(receiptUi) {
        mutableStateOf(
            if (receiptUi.entity.discountAmount > 0.0) {
                FormatUtils.formatCompact(receiptUi.entity.discountAmount)
            } else ""
        )
    }
    var editDiscountBeforeVat by remember(receiptUi) {
        mutableStateOf(receiptUi.entity.discountBeforeVat)
    }

    val previewDiscount = editDiscountText.toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0
    val previewTotals = remember(editItems, editVat, previewDiscount, editDiscountBeforeVat) {
        MueLaViewModel.calculateReceiptTotals(editItems, editVat, previewDiscount, editDiscountBeforeVat)
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = SurfaceWhite,
            border = BorderStroke(1.dp, SageBorder),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .widthIn(max = 580.dp)
        ) {
            Column(
                modifier = Modifier
                    .verticalScroll(rememberScrollState())
                    .padding(18.dp)
            ) {
                // Header Actions
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        MueLaLogo(size = 28.dp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isEditing) "แก้ไขใบเสร็จ" else "รายละเอียดใบเสร็จ",
                            fontFamily = PromptFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = DeepOlive
                        )
                    }

                    Row {
                        if (!isEditing) {
                            IconButton(
                                onClick = { isEditing = true },
                                modifier = Modifier.testTag("edit_receipt_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Edit,
                                    contentDescription = "แก้ไขใบเสร็จ",
                                    tint = DeepOlive
                                )
                            }
                            IconButton(
                                onClick = { showDeleteConfirm = true },
                                modifier = Modifier.testTag("delete_receipt_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.DeleteOutline,
                                    contentDescription = "ลบใบเสร็จ",
                                    tint = VibrantOrange
                                )
                            }
                        }
                        IconButton(onClick = onDismiss) {
                            Icon(
                                imageVector = Icons.Filled.Close,
                                contentDescription = "ปิด",
                                tint = MutedOliveText
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                if (isEditing) {
                    OutlinedTextField(
                        value = editStore,
                        onValueChange = { editStore = it },
                        label = { Text("ชื่อร้านค้า", fontFamily = PromptFontFamily) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = OliveGreen,
                            focusedLabelColor = DeepOlive
                        )
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = { showDatePicker = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.CalendarToday,
                            contentDescription = null,
                            tint = DeepOlive,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = FormatUtils.formatThaiDate(editDateMillis),
                            fontFamily = PromptFontFamily,
                            color = CharcoalText
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "รายการสินค้า",
                        fontFamily = PromptFontFamily,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 14.sp,
                        color = DeepOlive
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    editItems.forEachIndexed { idx, item ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MintBackground,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = item.name,
                                        fontFamily = PromptFontFamily,
                                        fontWeight = FontWeight.Medium,
                                        color = CharcoalText,
                                        modifier = Modifier.weight(1f)
                                    )
                                    if (editItems.size > 1) {
                                        IconButton(
                                            onClick = {
                                                editItems = editItems.filterIndexed { i, _ -> i != idx }
                                            }
                                        ) {
                                            Icon(
                                                imageVector = Icons.Filled.DeleteOutline,
                                                contentDescription = "ลบรายการ",
                                                tint = VibrantOrange,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    var qtyStr by remember(item.id) {
                                        mutableStateOf(FormatUtils.formatCompact(item.quantity))
                                    }
                                    var priceStr by remember(item.id) {
                                        mutableStateOf(
                                            FormatUtils.formatNumber(item.unitPrice).replace(",", "")
                                        )
                                    }
                                    OutlinedTextField(
                                        value = qtyStr,
                                        onValueChange = { s ->
                                            qtyStr = s
                                            val q = s.toDoubleOrNull()
                                            if (q != null && q > 0) {
                                                editItems = editItems.mapIndexed { i, it ->
                                                    if (i == idx) it.copy(quantity = q) else it
                                                }
                                            }
                                        },
                                        label = { Text("จำนวน (${item.unit})", fontFamily = PromptFontFamily, fontSize = 11.sp) },
                                        singleLine = true,
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                        modifier = Modifier.weight(1f)
                                    )
                                    OutlinedTextField(
                                        value = priceStr,
                                        onValueChange = { s ->
                                            priceStr = s
                                            val p = s.toDoubleOrNull()
                                            if (p != null && p >= 0) {
                                                editItems = editItems.mapIndexed { i, it ->
                                                    if (i == idx) it.copy(unitPrice = p) else it
                                                }
                                            }
                                        },
                                        label = { Text("ราคา/หน่วย", fontFamily = PromptFontFamily, fontSize = 11.sp) },
                                        singleLine = true,
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable { editVat = !editVat }
                    ) {
                        Checkbox(
                            checked = editVat,
                            onCheckedChange = { editVat = it },
                            colors = CheckboxDefaults.colors(checkedColor = OliveGreen)
                        )
                        Text("คำนวณ VAT 7%", fontFamily = PromptFontFamily, fontSize = 14.sp)
                    }

                    OutlinedTextField(
                        value = editDiscountText,
                        onValueChange = { editDiscountText = it },
                        label = { Text("ส่วนลด (บาท)", fontFamily = PromptFontFamily) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.fillMaxWidth()
                    )

                    if (editVat && previewDiscount > 0.0) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = editDiscountBeforeVat,
                                onClick = { editDiscountBeforeVat = true },
                                label = { Text("ลดก่อน VAT", fontFamily = PromptFontFamily, fontSize = 12.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = DeepOlive,
                                    selectedLabelColor = Color.White
                                )
                            )
                            FilterChip(
                                selected = !editDiscountBeforeVat,
                                onClick = { editDiscountBeforeVat = false },
                                label = { Text("ลดหลัง VAT", fontFamily = PromptFontFamily, fontSize = 12.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = DeepOlive,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    DashedReceiptDivider()
                    Spacer(modifier = Modifier.height(8.dp))
                    ReceiptSummaryLine("ยอดสุทธิใหม่", FormatUtils.formatBaht(previewTotals.grandTotal), VibrantOrange)

                    Spacer(modifier = Modifier.height(14.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = { isEditing = false },
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                        ) {
                            Text("ยกเลิก", fontFamily = PromptFontFamily, color = MutedOliveText)
                        }
                        Button(
                            onClick = {
                                onSaveEdit(
                                    editStore,
                                    editDateMillis,
                                    editItems,
                                    editVat,
                                    previewDiscount,
                                    editDiscountBeforeVat
                                )
                                isEditing = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = OliveGreen),
                            modifier = Modifier
                                .weight(1.5f)
                                .height(48.dp)
                                .testTag("save_receipt_edit_button")
                        ) {
                            Text("บันทึกการแก้ไข", fontFamily = PromptFontFamily, fontWeight = FontWeight.SemiBold)
                        }
                    }
                } else {
                    // Read-only Minimalist Receipt View
                    Text(
                        text = receiptUi.entity.storeName,
                        fontFamily = PromptFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp,
                        color = CharcoalText
                    )
                    Text(
                        text = FormatUtils.formatThaiDate(receiptUi.entity.purchaseDateMillis),
                        fontFamily = PromptFontFamily,
                        fontSize = 13.sp,
                        color = MutedOliveText
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    DashedReceiptDivider()
                    Spacer(modifier = Modifier.height(12.dp))

                    receiptUi.items.forEach { item ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.name,
                                    fontFamily = PromptFontFamily,
                                    fontWeight = FontWeight.Medium,
                                    fontSize = 14.sp,
                                    color = CharcoalText
                                )
                                Text(
                                    text = "${FormatUtils.formatCompact(item.quantity)} ${item.unit} × ${FormatUtils.formatBaht(item.unitPrice)}",
                                    fontFamily = PromptFontFamily,
                                    fontSize = 11.sp,
                                    color = MutedOliveText
                                )
                            }
                            Text(
                                text = FormatUtils.formatBaht(item.lineTotal),
                                fontFamily = MontserratFontFamily,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 14.sp,
                                color = CharcoalText
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    DashedReceiptDivider()
                    Spacer(modifier = Modifier.height(10.dp))

                    ReceiptSummaryLine("รวมสินค้า", FormatUtils.formatBaht(receiptUi.entity.subtotal))
                    if (receiptUi.entity.discountAmount > 0.0) {
                        ReceiptSummaryLine(
                            label = if (receiptUi.entity.discountBeforeVat) "ส่วนลด (ก่อน VAT)" else "ส่วนลด (หลัง VAT)",
                            amount = "-${FormatUtils.formatBaht(receiptUi.entity.discountAmount)}",
                            valueColor = OliveGreen
                        )
                    }
                    if (receiptUi.entity.includeVat) {
                        ReceiptSummaryLine("VAT 7%", FormatUtils.formatBaht(receiptUi.entity.vatAmount))
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = SoftOrangeBg,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "ยอดรวมสุทธิ",
                                fontFamily = PromptFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = CharcoalText
                            )
                            Text(
                                text = FormatUtils.formatBaht(receiptUi.entity.grandTotal),
                                fontFamily = MontserratFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 20.sp,
                                color = VibrantOrange
                            )
                        }
                    }
                }
            }
        }
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            containerColor = SurfaceWhite,
            title = { Text("ลบใบเสร็จ?", fontFamily = PromptFontFamily, fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "ต้องการลบใบเสร็จจาก ${receiptUi.entity.storeName} ใช่หรือไม่?",
                    fontFamily = PromptFontFamily
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteConfirm = false
                        onDelete()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = VibrantOrange)
                ) {
                    Text("ลบใบเสร็จ", fontFamily = PromptFontFamily)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text("ยกเลิก", fontFamily = PromptFontFamily, color = MutedOliveText)
                }
            }
        )
    }

    if (showDatePicker) {
        val datePickerState = rememberDatePickerState(initialSelectedDateMillis = editDateMillis)
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        datePickerState.selectedDateMillis?.let {
                            editDateMillis = FormatUtils.startOfDayMillis(it)
                        }
                        showDatePicker = false
                    }
                ) {
                    Text("ตกลง", fontFamily = PromptFontFamily, color = DeepOlive)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDatePicker = false }) {
                    Text("ยกเลิก", fontFamily = PromptFontFamily, color = MutedOliveText)
                }
            }
        ) {
            DatePicker(state = datePickerState)
        }
    }
}
