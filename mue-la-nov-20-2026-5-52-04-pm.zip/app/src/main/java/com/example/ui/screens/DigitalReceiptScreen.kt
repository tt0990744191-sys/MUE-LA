package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.CartItemEntity
import com.example.data.model.ReceiptLineItem
import com.example.ui.components.DashedReceiptDivider
import com.example.ui.components.MueLaLogo
import com.example.ui.theme.CharcoalText
import com.example.ui.theme.DeepOlive
import com.example.ui.theme.MintBackground
import com.example.ui.theme.MontserratFontFamily
import com.example.ui.theme.MutedOliveText
import com.example.ui.theme.OliveGreen
import com.example.ui.theme.PromptFontFamily
import com.example.ui.theme.SageBorder
import com.example.ui.theme.SoftOliveBg
import com.example.ui.theme.SoftOrangeBg
import com.example.ui.theme.SurfaceWhite
import com.example.ui.theme.VibrantOrange
import com.example.ui.viewmodel.MueLaViewModel
import com.example.util.FormatUtils

private val QuickStores = listOf("Makro", "นานาผักสด", "เอี้ยงผักสด")

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun DigitalReceiptScreen(
    selectedCartItems: List<CartItemEntity>,
    onGoToListFood: () -> Unit,
    onSaveReceipt: (
        storeName: String,
        purchaseDateMillis: Long,
        includeVat: Boolean,
        discountAmount: Double,
        discountBeforeVat: Boolean
    ) -> Unit
) {
    var storeName by remember { mutableStateOf("Makro") }
    var purchaseDateMillis by remember { mutableLongStateOf(FormatUtils.startOfDayMillis()) }
    var showDatePicker by remember { mutableStateOf(false) }
    var includeVat by remember { mutableStateOf(false) }
    var discountInput by remember { mutableStateOf("") }
    var discountBeforeVat by remember { mutableStateOf(true) }

    val lineItems = remember(selectedCartItems) {
        selectedCartItems.map {
            ReceiptLineItem(
                id = it.id,
                name = it.name,
                category = it.category,
                unit = it.unit,
                quantity = it.quantity,
                unitPrice = it.unitPrice,
                isWeighted = it.isWeighted,
                weightKg = it.weightKg,
                pricePerKg = it.pricePerKg
            )
        }
    }
    val discountValue = discountInput.toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0
    val totals = remember(lineItems, includeVat, discountValue, discountBeforeVat) {
        MueLaViewModel.calculateReceiptTotals(
            items = lineItems,
            includeVat = includeVat,
            discountAmount = discountValue,
            discountBeforeVat = discountBeforeVat
        )
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MintBackground),
        contentAlignment = Alignment.TopCenter
    ) {
        if (selectedCartItems.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 500.dp)
                    .padding(24.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .clip(CircleShape)
                        .background(SoftOliveBg),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.ReceiptLong,
                        contentDescription = null,
                        tint = OliveGreen,
                        modifier = Modifier.size(36.dp)
                    )
                }
                Spacer(modifier = Modifier.height(14.dp))
                Text(
                    text = "ยังไม่มีรายการสินค้าที่เลือกออกบิล",
                    fontFamily = PromptFontFamily,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 17.sp,
                    color = CharcoalText,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "กลับไปติ๊กเลือกรายการสินค้าในเมนู List Food แล้วกดออกใบเสร็จ",
                    fontFamily = PromptFontFamily,
                    fontSize = 13.sp,
                    color = MutedOliveText,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(18.dp))
                Button(
                    onClick = onGoToListFood,
                    colors = ButtonDefaults.buttonColors(containerColor = OliveGreen),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .height(48.dp)
                        .testTag("go_to_list_food_button")
                ) {
                    Text(
                        text = "ไปที่รายการซื้อของ",
                        fontFamily = PromptFontFamily,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 640.dp),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // 1. Store & Date Card
                item(key = "store_date_card") {
                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                        border = BorderStroke(1.dp, SageBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "ข้อมูลสถานที่และวันที่ซื้อ",
                                fontFamily = PromptFontFamily,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 15.sp,
                                color = DeepOlive
                            )
                            Spacer(modifier = Modifier.height(10.dp))

                            OutlinedTextField(
                                value = storeName,
                                onValueChange = { storeName = it },
                                label = { Text("ชื่อร้านค้า / ตลาด", fontFamily = PromptFontFamily) },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Filled.Storefront,
                                        contentDescription = null,
                                        tint = OliveGreen
                                    )
                                },
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("receipt_store_name_input"),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = OliveGreen,
                                    focusedLabelColor = DeepOlive
                                )
                            )

                            Spacer(modifier = Modifier.height(8.dp))
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                QuickStores.forEach { preset ->
                                    FilterChip(
                                        selected = storeName == preset,
                                        onClick = { storeName = preset },
                                        label = {
                                            Text(preset, fontFamily = PromptFontFamily, fontSize = 12.sp)
                                        },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = OliveGreen,
                                            selectedLabelColor = Color.White
                                        ),
                                        modifier = Modifier.testTag("quick_store_$preset")
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))
                            OutlinedButton(
                                onClick = { showDatePicker = true },
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, SageBorder),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("receipt_date_picker_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.CalendarToday,
                                    contentDescription = "เลือกวันที่ซื้อ",
                                    tint = DeepOlive,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "วันที่ซื้อ: ${FormatUtils.formatThaiDate(purchaseDateMillis)}",
                                    fontFamily = PromptFontFamily,
                                    color = CharcoalText,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }

                // 2. VAT & Discount Card
                item(key = "tax_discount_card") {
                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                        border = BorderStroke(1.dp, SageBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "ภาษีมูลค่าเพิ่มและส่วนลด",
                                fontFamily = PromptFontFamily,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 15.sp,
                                color = DeepOlive
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { includeVat = !includeVat }
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = includeVat,
                                    onCheckedChange = { includeVat = it },
                                    colors = CheckboxDefaults.colors(checkedColor = OliveGreen),
                                    modifier = Modifier.testTag("vat_checkbox")
                                )
                                Text(
                                    text = "คำนวณภาษีมูลค่าเพิ่ม VAT 7%",
                                    fontFamily = PromptFontFamily,
                                    fontWeight = FontWeight.Medium,
                                    fontSize = 14.sp,
                                    color = CharcoalText
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            OutlinedTextField(
                                value = discountInput,
                                onValueChange = { discountInput = it },
                                label = { Text("ส่วนลด (บาท)", fontFamily = PromptFontFamily) },
                                placeholder = { Text("0.00", fontFamily = MontserratFontFamily) },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("discount_input"),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = OliveGreen,
                                    focusedLabelColor = DeepOlive
                                )
                            )

                            if (includeVat && discountValue > 0.0) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    FilterChip(
                                        selected = discountBeforeVat,
                                        onClick = { discountBeforeVat = true },
                                        label = {
                                            Text("หักส่วนลดก่อน VAT", fontFamily = PromptFontFamily, fontSize = 12.sp)
                                        },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = DeepOlive,
                                            selectedLabelColor = Color.White
                                        )
                                    )
                                    FilterChip(
                                        selected = !discountBeforeVat,
                                        onClick = { discountBeforeVat = false },
                                        label = {
                                            Text("หักส่วนลดหลัง VAT", fontFamily = PromptFontFamily, fontSize = 12.sp)
                                        },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = DeepOlive,
                                            selectedLabelColor = Color.White
                                        )
                                    )
                                }
                            }
                        }
                    }
                }

                // 3. Minimalist Paper-Style Digital Receipt Preview
                item(key = "receipt_preview_card") {
                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                        border = BorderStroke(1.5.dp, DeepOlive.copy(alpha = 0.45f)),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(18.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    MueLaLogo(size = 28.dp)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "MUE LA RECEIPT",
                                        fontFamily = MontserratFontFamily,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = DeepOlive
                                    )
                                }
                                Text(
                                    text = FormatUtils.formatThaiDate(purchaseDateMillis),
                                    fontFamily = PromptFontFamily,
                                    fontSize = 12.sp,
                                    color = MutedOliveText
                                )
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = storeName.ifBlank { "ร้านค้าทั่วไป" },
                                fontFamily = PromptFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                color = CharcoalText
                            )

                            Spacer(modifier = Modifier.height(12.dp))
                            DashedReceiptDivider()
                            Spacer(modifier = Modifier.height(12.dp))

                            lineItems.forEach { item ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.Top
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = item.name,
                                            fontFamily = PromptFontFamily,
                                            fontWeight = FontWeight.Medium,
                                            fontSize = 14.sp,
                                            color = CharcoalText
                                        )
                                        Text(
                                            text = if (item.isWeighted) {
                                                "${FormatUtils.formatCompact(item.weightKg)} กก. × ${FormatUtils.formatBaht(item.pricePerKg)}"
                                            } else {
                                                "${FormatUtils.formatCompact(item.quantity)} ${item.unit} × ${FormatUtils.formatBaht(item.unitPrice)}"
                                            },
                                            fontFamily = PromptFontFamily,
                                            fontSize = 11.sp,
                                            color = MutedOliveText
                                        )
                                    }
                                    Text(
                                        text = FormatUtils.formatBaht(item.lineTotal),
                                        fontFamily = MontserratFontFamily,
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 14.sp,
                                        color = CharcoalText
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))
                            DashedReceiptDivider()
                            Spacer(modifier = Modifier.height(12.dp))

                            ReceiptSummaryLine(
                                label = "รวมสินค้า (${lineItems.size} รายการ)",
                                amount = FormatUtils.formatBaht(totals.subtotal)
                            )

                            if (totals.discountApplied > 0.0) {
                                ReceiptSummaryLine(
                                    label = if (discountBeforeVat) "ส่วนลด (ก่อน VAT)" else "ส่วนลด (หลัง VAT)",
                                    amount = "-${FormatUtils.formatBaht(totals.discountApplied)}",
                                    valueColor = OliveGreen
                                )
                            }

                            if (includeVat) {
                                ReceiptSummaryLine(
                                    label = "ยอดก่อนภาษีมูลค่าเพิ่ม",
                                    amount = FormatUtils.formatBaht(totals.taxableBase)
                                )
                                ReceiptSummaryLine(
                                    label = "ภาษีมูลค่าเพิ่ม VAT 7%",
                                    amount = FormatUtils.formatBaht(totals.vatAmount)
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = SoftOrangeBg,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 14.dp, vertical = 12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "ยอดรวมสุทธิ",
                                        fontFamily = PromptFontFamily,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp,
                                        color = CharcoalText
                                    )
                                    Text(
                                        text = FormatUtils.formatBaht(totals.grandTotal),
                                        fontFamily = MontserratFontFamily,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 22.sp,
                                        color = VibrantOrange
                                    )
                                }
                            }
                        }
                    }
                }

                // 4. Save Receipt Button
                item(key = "save_receipt_cta") {
                    Button(
                        onClick = {
                            onSaveReceipt(
                                storeName,
                                purchaseDateMillis,
                                includeVat,
                                discountValue,
                                discountBeforeVat
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = OliveGreen),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .testTag("save_digital_receipt_button")
                    ) {
                        Icon(imageVector = Icons.Filled.CheckCircle, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "บันทึกใบเสร็จและล้างตะกร้าที่เลือก",
                            fontFamily = PromptFontFamily,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 15.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }
    }

    if (showDatePicker) {
        val datePickerState = rememberDatePickerState(initialSelectedDateMillis = purchaseDateMillis)
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        datePickerState.selectedDateMillis?.let {
                            purchaseDateMillis = FormatUtils.startOfDayMillis(it)
                        }
                        showDatePicker = false
                    }
                ) {
                    Text("ตกลง", fontFamily = PromptFontFamily, color = DeepOlive)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDatePicker = false }) {
                    Text("ยกเลิก", fontFamily = PromptFontFamily, color = MutedOliveText)
                }
            }
        ) {
            DatePicker(state = datePickerState)
        }
    }
}

@Composable
fun ReceiptSummaryLine(
    label: String,
    amount: String,
    valueColor: Color = CharcoalText
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            fontFamily = PromptFontFamily,
            fontSize = 13.sp,
            color = MutedOliveText
        )
        Text(
            text = amount,
            fontFamily = MontserratFontFamily,
            fontWeight = FontWeight.Medium,
            fontSize = 13.sp,
            color = valueColor
        )
    }
}
