package com.example.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ReceiptLong
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Scale
import androidx.compose.material.icons.filled.ShoppingBasket
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.CartItemEntity
import com.example.data.model.FoodCategory
import com.example.data.model.FoodUnit
import com.example.data.model.RoundingMode
import com.example.ui.theme.CharcoalText
import com.example.ui.theme.DeepOlive
import com.example.ui.theme.MintBackground
import com.example.ui.theme.MontserratFontFamily
import com.example.ui.theme.MutedOliveText
import com.example.ui.theme.OliveGreen
import com.example.ui.theme.PromptFontFamily
import com.example.ui.theme.SageBorder
import com.example.ui.theme.SoftOliveBg
import com.example.ui.theme.SoftOrangeBg
import com.example.ui.theme.SoftSage
import com.example.ui.theme.SurfaceWhite
import com.example.ui.theme.VibrantOrange
import com.example.util.FormatUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ListFoodScreen(
    budgetLimit: Double,
    cartItems: List<CartItemEntity>,
    onUpdateBudget: (Double) -> Unit,
    onAddCartItem: (
        name: String,
        category: String,
        unit: String,
        isWeighted: Boolean,
        weightKg: Double,
        pricePerKg: Double,
        roundingMode: RoundingMode,
        quantity: Double,
        unitPrice: Double
    ) -> Unit,
    onToggleSelect: (CartItemEntity) -> Unit,
    onSetAllSelected: (Boolean) -> Unit,
    onUpdateQtyAndPrice: (CartItemEntity, Double, Double) -> Unit,
    onDeleteItem: (String) -> Unit,
    onIssueReceiptClick: () -> Unit
) {
    val selectedItems = remember(cartItems) { cartItems.filter { it.isSelected } }
    val selectedTotal = remember(selectedItems) { selectedItems.sumOf { it.lineTotal } }
    val allSelected = cartItems.isNotEmpty() && selectedItems.size == cartItems.size

    var showBudgetDialog by remember { mutableStateOf(false) }
    var editingItem by remember { mutableStateOf<CartItemEntity?>(null) }
    var showAddItemSheet by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MintBackground),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 640.dp)
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(
                        start = 16.dp,
                        end = 16.dp,
                        top = 16.dp,
                        bottom = 88.dp
                    ),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // 1. Budget Tracker Card
                    item(key = "budget_tracker") {
                        BudgetTrackerCard(
                            budgetLimit = budgetLimit,
                            currentTotal = selectedTotal,
                            onEditBudgetClick = { showBudgetDialog = true }
                        )
                    }

                    // 2. Select All Header & Clean Cart List
                    if (cartItems.isNotEmpty()) {
                        item(key = "select_all_bar") {
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = SurfaceWhite,
                                border = BorderStroke(1.dp, SageBorder),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { onSetAllSelected(!allSelected) }
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                        .testTag("select_all_row"),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Checkbox(
                                            checked = allSelected,
                                            onCheckedChange = { onSetAllSelected(it) },
                                            colors = CheckboxDefaults.colors(
                                                checkedColor = OliveGreen,
                                                uncheckedColor = MutedOliveText
                                            ),
                                            modifier = Modifier.testTag("select_all_checkbox")
                                        )
                                        Text(
                                            text = if (allSelected) "ยกเลิกเลือกทั้งหมด" else "เลือกทั้งหมด",
                                            fontFamily = PromptFontFamily,
                                            fontWeight = FontWeight.Medium,
                                            fontSize = 14.sp,
                                            color = CharcoalText
                                        )
                                    }
                                    Text(
                                        text = "เลือก ${selectedItems.size}/${cartItems.size} รายการ",
                                        fontFamily = PromptFontFamily,
                                        fontSize = 12.sp,
                                        color = MutedOliveText
                                    )
                                }
                            }
                        }

                        items(cartItems, key = { it.id }) { item ->
                            CartItemCard(
                                item = item,
                                onToggleSelect = { onToggleSelect(item) },
                                onDecrementQty = {
                                    val step = if (item.quantity > 1.0) 1.0 else 0.5
                                    val nextQty = (item.quantity - step).coerceAtLeast(0.5)
                                    onUpdateQtyAndPrice(item, nextQty, item.unitPrice)
                                },
                                onIncrementQty = {
                                    onUpdateQtyAndPrice(item, item.quantity + 1.0, item.unitPrice)
                                },
                                onEditClick = { editingItem = item },
                                onDeleteClick = { onDeleteItem(item.id) }
                            )
                        }
                    } else {
                        item(key = "empty_cart") {
                            EmptyCartState(onOpenAddSheet = { showAddItemSheet = true })
                        }
                    }
                }

                // Floating Add Item Button (clean & always reachable)
                ExtendedFloatingActionButton(
                    onClick = { showAddItemSheet = true },
                    containerColor = OliveGreen,
                    contentColor = Color.White,
                    shape = RoundedCornerShape(16.dp),
                    icon = {
                        Icon(
                            imageVector = Icons.Filled.Add,
                            contentDescription = "เพิ่มสินค้า"
                        )
                    },
                    text = {
                        Text(
                            text = "เพิ่มสินค้า",
                            fontFamily = PromptFontFamily,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 14.sp
                        )
                    },
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(16.dp)
                        .testTag("open_add_item_sheet_fab")
                )
            }

            // Bottom Checkout CTA Strip
            if (cartItems.isNotEmpty()) {
                Surface(
                    color = SurfaceWhite,
                    shadowElevation = 8.dp,
                    border = BorderStroke(1.dp, SageBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "ยอดที่เลือกออกบิล (${selectedItems.size} รายการ)",
                                fontFamily = PromptFontFamily,
                                fontSize = 12.sp,
                                color = MutedOliveText
                            )
                            Text(
                                text = FormatUtils.formatBaht(selectedTotal),
                                fontFamily = MontserratFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 20.sp,
                                color = VibrantOrange
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Button(
                            onClick = onIssueReceiptClick,
                            enabled = selectedItems.isNotEmpty(),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = VibrantOrange,
                                disabledContainerColor = SoftSage
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .height(48.dp)
                                .testTag("issue_digital_receipt_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ReceiptLong,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "ออกใบเสร็จ",
                                fontFamily = PromptFontFamily,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }
        }
    }

    if (showAddItemSheet) {
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(
            onDismissRequest = { showAddItemSheet = false },
            sheetState = sheetState,
            containerColor = SurfaceWhite
        ) {
            AddCartItemSheetContent(
                onDismiss = { showAddItemSheet = false },
                onAddItem = { name, cat, unit, weighted, wKg, pKg, rMode, qty, uPrice ->
                    onAddCartItem(name, cat, unit, weighted, wKg, pKg, rMode, qty, uPrice)
                    showAddItemSheet = false
                }
            )
        }
    }

    if (showBudgetDialog) {
        EditBudgetDialog(
            currentBudget = budgetLimit,
            onDismiss = { showBudgetDialog = false },
            onSave = { newBudget ->
                onUpdateBudget(newBudget)
                showBudgetDialog = false
            }
        )
    }

    editingItem?.let { item ->
        EditCartItemDialog(
            item = item,
            onDismiss = { editingItem = null },
            onSave = { qty, price ->
                onUpdateQtyAndPrice(item, qty, price)
                editingItem = null
            }
        )
    }
}

@Composable
private fun BudgetTrackerCard(
    budgetLimit: Double,
    currentTotal: Double,
    onEditBudgetClick: () -> Unit
) {
    val isOverBudget = budgetLimit > 0.0 && currentTotal > budgetLimit
    val rawRatio = if (budgetLimit > 0.0) (currentTotal / budgetLimit).toFloat().coerceIn(0f, 1f) else 0f
    val animatedProgress by animateFloatAsState(
        targetValue = rawRatio,
        animationSpec = tween(90),
        label = "budget_progress"
    )
    val accentColor by animateColorAsState(
        targetValue = if (isOverBudget) VibrantOrange else OliveGreen,
        animationSpec = tween(90),
        label = "budget_color"
    )
    val remaining = budgetLimit - currentTotal

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
        border = BorderStroke(1.dp, if (isOverBudget) VibrantOrange else SageBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "งบประมาณการซื้อรอบนี้",
                        fontFamily = PromptFontFamily,
                        fontSize = 13.sp,
                        color = MutedOliveText
                    )
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(
                            text = FormatUtils.formatBaht(budgetLimit),
                            fontFamily = MontserratFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 22.sp,
                            color = DeepOlive
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "/ รอบ",
                            fontFamily = PromptFontFamily,
                            fontSize = 12.sp,
                            color = MutedOliveText,
                            modifier = Modifier.padding(bottom = 3.dp)
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = SoftOliveBg,
                    modifier = Modifier
                        .height(48.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .clickable(onClick = onEditBudgetClick)
                        .testTag("edit_budget_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Edit,
                            contentDescription = "แก้ไขงบประมาณ",
                            tint = DeepOlive,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "ตั้งงบ",
                            fontFamily = PromptFontFamily,
                            fontWeight = FontWeight.Medium,
                            fontSize = 13.sp,
                            color = DeepOlive
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            LinearProgressIndicator(
                progress = { animatedProgress },
                color = accentColor,
                trackColor = SoftSage,
                strokeCap = StrokeCap.Round,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(10.dp)
                    .clip(RoundedCornerShape(5.dp))
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (isOverBudget) {
                        Icon(
                            imageVector = Icons.Filled.WarningAmber,
                            contentDescription = "เกินงบประมาณ",
                            tint = VibrantOrange,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                    }
                    Text(
                        text = if (isOverBudget) {
                            "เกินงบ ${FormatUtils.formatBaht(-remaining)}"
                        } else {
                            "คงเหลือ ${FormatUtils.formatBaht(remaining)}"
                        },
                        fontFamily = PromptFontFamily,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp,
                        color = if (isOverBudget) VibrantOrange else DeepOlive
                    )
                }

                Text(
                    text = "ในตะกร้า ${FormatUtils.formatBaht(currentTotal)}",
                    fontFamily = MontserratFontFamily,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp,
                    color = if (isOverBudget) VibrantOrange else CharcoalText
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AddCartItemSheetContent(
    onDismiss: () -> Unit,
    onAddItem: (
        name: String,
        category: String,
        unit: String,
        isWeighted: Boolean,
        weightKg: Double,
        pricePerKg: Double,
        roundingMode: RoundingMode,
        quantity: Double,
        unitPrice: Double
    ) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf(FoodCategory.FRESH_FOOD) }
    var selectedUnit by remember { mutableStateOf(FoodUnit.KG) }
    var isWeighted by remember { mutableStateOf(false) }
    var weightInput by remember { mutableStateOf("") }
    var pricePerKgInput by remember { mutableStateOf("") }
    var roundingMode by remember { mutableStateOf(RoundingMode.QUARTER_25) }
    var qtyInput by remember { mutableStateOf("1") }
    var unitPriceInput by remember { mutableStateOf("") }
    var errorText by remember { mutableStateOf<String?>(null) }

    val parsedWeight = weightInput.toDoubleOrNull() ?: 0.0
    val parsedPriceKg = pricePerKgInput.toDoubleOrNull() ?: 0.0
    val rawWeightedPrice = parsedWeight * parsedPriceKg
    val roundedWeightedPrice = FormatUtils.roundThaiRetail(rawWeightedPrice, roundingMode)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
            .padding(bottom = 28.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(SoftOliveBg),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.Add,
                        contentDescription = null,
                        tint = DeepOlive,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "เพิ่มรายการสินค้า",
                    fontFamily = PromptFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = DeepOlive
                )
            }
            IconButton(onClick = onDismiss) {
                Icon(
                    imageVector = Icons.Filled.Close,
                    contentDescription = "ปิดหน้าต่างเพิ่มสินค้า",
                    tint = MutedOliveText
                )
            }
        }

        HorizontalDivider(color = SoftSage, modifier = Modifier.padding(vertical = 10.dp))

                    OutlinedTextField(
                        value = name,
                        onValueChange = {
                            name = it
                            errorText = null
                        },
                        label = { Text("ชื่อสินค้า / วัตถุดิบ", fontFamily = PromptFontFamily) },
                        placeholder = { Text("เช่น สันในไก่, คะน้า, น้ำปลา", fontFamily = PromptFontFamily) },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("add_item_name_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = OliveGreen,
                            focusedLabelColor = DeepOlive
                        )
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "หมวดหมู่",
                        fontFamily = PromptFontFamily,
                        fontWeight = FontWeight.Medium,
                        fontSize = 13.sp,
                        color = CharcoalText
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(FoodCategory.entries, key = { it.name }) { cat ->
                            FilterChip(
                                selected = selectedCategory == cat,
                                onClick = { selectedCategory = cat },
                                label = {
                                    Text(cat.label, fontFamily = PromptFontFamily, fontSize = 12.sp)
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = OliveGreen,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "หน่วยนับ",
                        fontFamily = PromptFontFamily,
                        fontWeight = FontWeight.Medium,
                        fontSize = 13.sp,
                        color = CharcoalText
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(FoodUnit.entries, key = { it.name }) { unit ->
                            FilterChip(
                                selected = selectedUnit == unit,
                                onClick = { selectedUnit = unit },
                                label = {
                                    Text(unit.label, fontFamily = PromptFontFamily, fontSize = 12.sp)
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = DeepOlive,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Makro Weighted Mode Switch
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = SoftOliveBg.copy(alpha = 0.65f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Scale,
                                    contentDescription = null,
                                    tint = DeepOlive,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = "สินค้าชั่งน้ำหนัก (แบบแมคโคร)",
                                        fontFamily = PromptFontFamily,
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 13.sp,
                                        color = CharcoalText
                                    )
                                    Text(
                                        text = "คำนวณน้ำหนัก × ราคา/กก. + ปัดเศษสตางค์",
                                        fontFamily = PromptFontFamily,
                                        fontSize = 11.sp,
                                        color = MutedOliveText
                                    )
                                }
                            }
                            Switch(
                                checked = isWeighted,
                                onCheckedChange = {
                                    isWeighted = it
                                    if (it) selectedUnit = FoodUnit.KG
                                    errorText = null
                                },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = OliveGreen
                                ),
                                modifier = Modifier.testTag("weighted_mode_switch")
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    if (isWeighted) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedTextField(
                                value = weightInput,
                                onValueChange = {
                                    weightInput = it
                                    errorText = null
                                },
                                label = { Text("น้ำหนัก (กก.)", fontFamily = PromptFontFamily) },
                                placeholder = { Text("0.45", fontFamily = MontserratFontFamily) },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("weight_kg_input"),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = OliveGreen,
                                    focusedLabelColor = DeepOlive
                                )
                            )
                            OutlinedTextField(
                                value = pricePerKgInput,
                                onValueChange = {
                                    pricePerKgInput = it
                                    errorText = null
                                },
                                label = { Text("ราคา/กก. (฿)", fontFamily = PromptFontFamily) },
                                placeholder = { Text("189", fontFamily = MontserratFontFamily) },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("price_per_kg_input"),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = OliveGreen,
                                    focusedLabelColor = DeepOlive
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "การปัดเศษสตางค์",
                            fontFamily = PromptFontFamily,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = CharcoalText
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            RoundingMode.entries.forEach { mode ->
                                FilterChip(
                                    selected = roundingMode == mode,
                                    onClick = { roundingMode = mode },
                                    label = {
                                        Text(mode.label, fontFamily = PromptFontFamily, fontSize = 11.sp)
                                    },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = VibrantOrange,
                                        selectedLabelColor = Color.White
                                    )
                                )
                            }
                        }

                        if (rawWeightedPrice > 0.0) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = SoftOrangeBg,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "ดิบ ${FormatUtils.formatBaht(rawWeightedPrice)} → ปัดเป็น",
                                        fontFamily = PromptFontFamily,
                                        fontSize = 12.sp,
                                        color = CharcoalText
                                    )
                                    Text(
                                        text = FormatUtils.formatBaht(roundedWeightedPrice),
                                        fontFamily = MontserratFontFamily,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = VibrantOrange
                                    )
                                }
                            }
                        }
                    } else {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedTextField(
                                value = qtyInput,
                                onValueChange = {
                                    qtyInput = it
                                    errorText = null
                                },
                                label = { Text("จำนวน", fontFamily = PromptFontFamily) },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("unit_qty_input"),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = OliveGreen,
                                    focusedLabelColor = DeepOlive
                                )
                            )
                            OutlinedTextField(
                                value = unitPriceInput,
                                onValueChange = {
                                    unitPriceInput = it
                                    errorText = null
                                },
                                label = { Text("ราคา/หน่วย (฿)", fontFamily = PromptFontFamily) },
                                placeholder = { Text("0.00", fontFamily = MontserratFontFamily) },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                modifier = Modifier
                                    .weight(1.4f)
                                    .testTag("unit_price_input"),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = OliveGreen,
                                    focusedLabelColor = DeepOlive
                                )
                            )
                        }
                    }

                    if (errorText != null) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = errorText!!,
                            fontFamily = PromptFontFamily,
                            fontSize = 12.sp,
                            color = VibrantOrange
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Button(
                        onClick = {
                            if (name.isBlank()) {
                                errorText = "กรุณากรอกชื่อสินค้า"
                                return@Button
                            }
                            if (isWeighted) {
                                if (parsedWeight <= 0.0 || parsedPriceKg <= 0.0) {
                                    errorText = "กรุณากรอกน้ำหนักและราคาต่อกิโลกรัมให้ถูกต้อง"
                                    return@Button
                                }
                                onAddItem(
                                    name.trim(),
                                    selectedCategory.label,
                                    selectedUnit.label,
                                    true,
                                    parsedWeight,
                                    parsedPriceKg,
                                    roundingMode,
                                    1.0,
                                    roundedWeightedPrice
                                )
                                name = ""
                                weightInput = ""
                                pricePerKgInput = ""
                            } else {
                                val qty = qtyInput.toDoubleOrNull() ?: 0.0
                                val price = unitPriceInput.toDoubleOrNull() ?: -1.0
                                if (qty <= 0.0 || price < 0.0) {
                                    errorText = "กรุณากรอกจำนวนและราคาต่อหน่วยให้ถูกต้อง"
                                    return@Button
                                }
                                onAddItem(
                                    name.trim(),
                                    selectedCategory.label,
                                    selectedUnit.label,
                                    false,
                                    0.0,
                                    0.0,
                                    RoundingMode.NONE,
                                    qty,
                                    price
                                )
                                name = ""
                                qtyInput = "1"
                                unitPriceInput = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = OliveGreen),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("add_item_submit_button")
                    ) {
                        Icon(imageVector = Icons.Filled.Add, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "เพิ่มลงรายการซื้อของ",
                            fontFamily = PromptFontFamily,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
    }
}

@Composable
private fun CartItemCard(
    item: CartItemEntity,
    onToggleSelect: () -> Unit,
    onDecrementQty: () -> Unit,
    onIncrementQty: () -> Unit,
    onEditClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (item.isSelected) SurfaceWhite else SurfaceWhite.copy(alpha = 0.72f)
        ),
        border = BorderStroke(1.dp, if (item.isSelected) OliveGreen.copy(alpha = 0.7f) else SageBorder),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("cart_item_card_${item.id}")
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Checkbox(
                    checked = item.isSelected,
                    onCheckedChange = { onToggleSelect() },
                    colors = CheckboxDefaults.colors(checkedColor = OliveGreen),
                    modifier = Modifier.testTag("cart_item_checkbox_${item.id}")
                )

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = item.name,
                        fontFamily = PromptFontFamily,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 15.sp,
                        color = CharcoalText,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = SoftOliveBg
                        ) {
                            Text(
                                text = item.category,
                                fontFamily = PromptFontFamily,
                                fontSize = 11.sp,
                                color = DeepOlive,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                        if (item.isWeighted) {
                            Text(
                                text = "${FormatUtils.formatCompact(item.weightKg)} กก. × ${FormatUtils.formatBaht(item.pricePerKg)}/กก.",
                                fontFamily = PromptFontFamily,
                                fontSize = 11.sp,
                                color = MutedOliveText
                            )
                        } else {
                            Text(
                                text = "${FormatUtils.formatBaht(item.unitPrice)} / ${item.unit}",
                                fontFamily = PromptFontFamily,
                                fontSize = 11.sp,
                                color = MutedOliveText
                            )
                        }
                    }
                }

                IconButton(
                    onClick = onEditClick,
                    modifier = Modifier.testTag("edit_cart_item_${item.id}")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Edit,
                        contentDescription = "แก้ไขจำนวนหรือราคา",
                        tint = DeepOlive,
                        modifier = Modifier.size(18.dp)
                    )
                }
                IconButton(
                    onClick = onDeleteClick,
                    modifier = Modifier.testTag("delete_cart_item_${item.id}")
                ) {
                    Icon(
                        imageVector = Icons.Filled.DeleteOutline,
                        contentDescription = "ลบสินค้า",
                        tint = VibrantOrange,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            HorizontalDivider(
                color = SoftSage,
                modifier = Modifier.padding(vertical = 6.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Inline Quantity Stepper
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = SoftSage,
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .clickable(onClick = onDecrementQty)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Filled.Remove,
                                contentDescription = "ลดจำนวน",
                                tint = CharcoalText,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                    Text(
                        text = "${FormatUtils.formatCompact(item.quantity)} ${item.unit}",
                        fontFamily = PromptFontFamily,
                        fontWeight = FontWeight.Medium,
                        fontSize = 13.sp,
                        color = CharcoalText,
                        modifier = Modifier
                            .clickable(onClick = onEditClick)
                            .padding(horizontal = 4.dp)
                    )
                    Surface(
                        shape = CircleShape,
                        color = SoftOliveBg,
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .clickable(onClick = onIncrementQty)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Filled.Add,
                                contentDescription = "เพิ่มจำนวน",
                                tint = DeepOlive,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }

                // Line Total
                Text(
                    text = FormatUtils.formatBaht(item.lineTotal),
                    fontFamily = MontserratFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    color = if (item.isSelected) DeepOlive else MutedOliveText
                )
            }
        }
    }
}

@Composable
private fun EmptyCartState(onOpenAddSheet: () -> Unit) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
        border = BorderStroke(1.dp, SageBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(SoftOliveBg),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.ShoppingBasket,
                    contentDescription = null,
                    tint = OliveGreen,
                    modifier = Modifier.size(32.dp)
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "ตะกร้ารายการซื้อยังว่างอยู่",
                fontFamily = PromptFontFamily,
                fontWeight = FontWeight.SemiBold,
                fontSize = 16.sp,
                color = CharcoalText
            )
            Text(
                text = "กดปุ่ม \"+ เพิ่มสินค้า\" เพื่อบันทึกรายการและคำนวณงบแบบเรียลไทม์",
                fontFamily = PromptFontFamily,
                fontSize = 13.sp,
                color = MutedOliveText
            )
            Spacer(modifier = Modifier.height(12.dp))
            Button(
                onClick = onOpenAddSheet,
                colors = ButtonDefaults.buttonColors(containerColor = OliveGreen),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.height(48.dp)
            ) {
                Icon(imageVector = Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "เพิ่มรายการแรก",
                    fontFamily = PromptFontFamily,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
private fun EditBudgetDialog(
    currentBudget: Double,
    onDismiss: () -> Unit,
    onSave: (Double) -> Unit
) {
    var budgetText by remember { mutableStateOf(FormatUtils.formatCompact(currentBudget)) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = SurfaceWhite,
        title = {
            Text(
                text = "ตั้งงบประมาณต่อรอบ (บาท)",
                fontFamily = PromptFontFamily,
                fontWeight = FontWeight.Bold,
                color = DeepOlive
            )
        },
        text = {
            OutlinedTextField(
                value = budgetText,
                onValueChange = { budgetText = it },
                label = { Text("วงเงินงบประมาณ (฿)", fontFamily = PromptFontFamily) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("budget_dialog_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = OliveGreen,
                    focusedLabelColor = DeepOlive
                )
            )
        },
        confirmButton = {
            Button(
                onClick = {
                    val value = budgetText.toDoubleOrNull() ?: currentBudget
                    onSave(value.coerceAtLeast(0.0))
                },
                colors = ButtonDefaults.buttonColors(containerColor = OliveGreen),
                modifier = Modifier.testTag("budget_dialog_save")
            ) {
                Text("บันทึก", fontFamily = PromptFontFamily)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("ยกเลิก", fontFamily = PromptFontFamily, color = MutedOliveText)
            }
        }
    )
}

@Composable
private fun EditCartItemDialog(
    item: CartItemEntity,
    onDismiss: () -> Unit,
    onSave: (Double, Double) -> Unit
) {
    var qtyText by remember { mutableStateOf(FormatUtils.formatCompact(item.quantity)) }
    var priceText by remember { mutableStateOf(FormatUtils.formatNumber(item.unitPrice).replace(",", "")) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = SurfaceWhite,
        title = {
            Text(
                text = "แก้ไข ${item.name}",
                fontFamily = PromptFontFamily,
                fontWeight = FontWeight.Bold,
                color = DeepOlive,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = qtyText,
                    onValueChange = { qtyText = it },
                    label = { Text("จำนวน (${item.unit})", fontFamily = PromptFontFamily) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = OliveGreen,
                        focusedLabelColor = DeepOlive
                    )
                )
                OutlinedTextField(
                    value = priceText,
                    onValueChange = { priceText = it },
                    label = { Text("ราคาต่อหน่วย (฿)", fontFamily = PromptFontFamily) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = OliveGreen,
                        focusedLabelColor = DeepOlive
                    )
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val q = qtyText.toDoubleOrNull() ?: item.quantity
                    val p = priceText.toDoubleOrNull() ?: item.unitPrice
                    onSave(q, p)
                },
                colors = ButtonDefaults.buttonColors(containerColor = OliveGreen)
            ) {
                Text("อัปเดต", fontFamily = PromptFontFamily)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("ยกเลิก", fontFamily = PromptFontFamily, color = MutedOliveText)
            }
        }
    )
}
