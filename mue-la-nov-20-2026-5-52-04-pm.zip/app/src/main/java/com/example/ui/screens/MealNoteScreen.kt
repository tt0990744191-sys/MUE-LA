package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.RestaurantMenu
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MealIngredient
import com.example.ui.components.DashedReceiptDivider
import com.example.ui.components.MueLaLogo
import com.example.ui.theme.CharcoalText
import com.example.ui.theme.DeepOlive
import com.example.ui.theme.MintBackground
import com.example.ui.theme.MontserratFontFamily
import com.example.ui.theme.MutedOliveText
import com.example.ui.theme.OliveGreen
import com.example.ui.theme.PromptFontFamily
import com.example.ui.theme.SageBorder
import com.example.ui.theme.SoftOliveBg
import com.example.ui.theme.SoftOrangeBg
import com.example.ui.theme.SoftSage
import com.example.ui.theme.SurfaceWhite
import com.example.ui.theme.VibrantOrange
import com.example.ui.viewmodel.MealPlanUiModel
import com.example.ui.viewmodel.ReceiptUiModel
import com.example.util.FormatUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MealNoteScreen(
    mealsPerDay: Int,
    receipts: List<ReceiptUiModel>,
    workingIngredients: List<MealIngredient>,
    useWholeSetMeals: Boolean,
    wholeSetMealsCount: Int,
    savedMealPlans: List<MealPlanUiModel>,
    onUpdateMealsPerDay: (Int) -> Unit,
    onImportFromReceipt: (ReceiptUiModel) -> Unit,
    onAddManualIngredient: (name: String, cost: Double, meals: Int) -> Unit,
    onUpdateIngredientMeals: (id: String, meals: Int) -> Unit,
    onRemoveIngredient: (id: String) -> Unit,
    onSetWholeSetMode: (Boolean) -> Unit,
    onSetWholeSetMealsCount: (Int) -> Unit,
    onSaveMealPlanSummary: (customTitle: String) -> Unit,
    onDeleteMealPlan: (id: String) -> Unit
) {
    var showReceiptPicker by remember { mutableStateOf(false) }
    var showManualDialog by remember { mutableStateOf(false) }
    var showSaveTitleDialog by remember { mutableStateOf(false) }

    val totalCost = remember(workingIngredients) { workingIngredients.sumOf { it.cost } }
    val totalMeals = remember(workingIngredients, useWholeSetMeals, wholeSetMealsCount) {
        if (workingIngredients.isEmpty()) 0
        else if (useWholeSetMeals) wholeSetMealsCount.coerceAtLeast(1)
        else workingIngredients.sumOf { it.estimatedMeals }.coerceAtLeast(1)
    }
    val estimatedDays = remember(totalMeals, mealsPerDay) {
        if (totalMeals == 0) 0.0 else totalMeals.toDouble() / mealsPerDay.coerceAtLeast(1).toDouble()
    }
    val costPerMeal = remember(totalCost, totalMeals) {
        if (totalMeals == 0) 0.0 else totalCost / totalMeals.toDouble()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MintBackground),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 640.dp),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // 1. Baseline Meals Per Day Setting Card
            item(key = "meals_per_day_card") {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                    border = BorderStroke(1.dp, SageBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "เกณฑ์การกินต่อวัน",
                                fontFamily = PromptFontFamily,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 15.sp,
                                color = DeepOlive
                            )
                            Text(
                                text = "ใช้คำนวณจำนวนวันที่วัตถุดิบจะอยู่ได้",
                                fontFamily = PromptFontFamily,
                                fontSize = 12.sp,
                                color = MutedOliveText
                            )
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = SoftSage,
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .clickable { onUpdateMealsPerDay(mealsPerDay - 1) }
                                    .testTag("meals_per_day_minus")
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Filled.Remove, contentDescription = "ลดมื้อต่อวัน")
                                }
                            }
                            Text(
                                text = "$mealsPerDay มื้อ/วัน",
                                fontFamily = PromptFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = CharcoalText
                            )
                            Surface(
                                shape = CircleShape,
                                color = SoftOliveBg,
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .clickable { onUpdateMealsPerDay(mealsPerDay + 1) }
                                    .testTag("meals_per_day_plus")
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Filled.Add, contentDescription = "เพิ่มมื้อต่อวัน", tint = DeepOlive)
                                }
                            }
                        }
                    }
                }
            }

            // 2. Import & Add Buttons
            item(key = "import_add_actions") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = { showReceiptPicker = true },
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.2.dp, OliveGreen),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("import_from_receipt_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.ReceiptLong,
                            contentDescription = null,
                            tint = DeepOlive,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "ดึงจากใบเสร็จ",
                            fontFamily = PromptFontFamily,
                            fontWeight = FontWeight.Medium,
                            color = DeepOlive,
                            fontSize = 13.sp,
                            maxLines = 1
                        )
                    }

                    Button(
                        onClick = { showManualDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = OliveGreen),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("add_manual_ingredient_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Add,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "+ เพิ่มวัตถุดิบเอง",
                            fontFamily = PromptFontFamily,
                            fontWeight = FontWeight.Medium,
                            fontSize = 13.sp,
                            maxLines = 1
                        )
                    }
                }
            }

            // 3. Working Ingredients Allocation & Live Calculation
            if (workingIngredients.isNotEmpty()) {
                item(key = "allocation_mode") {
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                        border = BorderStroke(1.dp, SageBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "วิธีระบุจำนวนมื้อที่แบ่งกินได้",
                                fontFamily = PromptFontFamily,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 14.sp,
                                color = DeepOlive
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(
                                    selected = !useWholeSetMeals,
                                    onClick = { onSetWholeSetMode(false) },
                                    label = {
                                        Text("ระบุรายวัตถุดิบ", fontFamily = PromptFontFamily, fontSize = 12.sp)
                                    },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = OliveGreen,
                                        selectedLabelColor = Color.White
                                    )
                                )
                                FilterChip(
                                    selected = useWholeSetMeals,
                                    onClick = { onSetWholeSetMode(true) },
                                    label = {
                                        Text("แบ่งรวมทั้งชุด", fontFamily = PromptFontFamily, fontSize = 12.sp)
                                    },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = OliveGreen,
                                        selectedLabelColor = Color.White
                                    )
                                )
                            }

                            if (useWholeSetMeals) {
                                Spacer(modifier = Modifier.height(10.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "วัตถุดิบชุดนี้กินได้รวมทั้งหมด",
                                        fontFamily = PromptFontFamily,
                                        fontSize = 13.sp,
                                        color = CharcoalText
                                    )
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Surface(
                                            shape = CircleShape,
                                            color = SoftSage,
                                            modifier = Modifier
                                                .size(36.dp)
                                                .clip(CircleShape)
                                                .clickable { onSetWholeSetMealsCount(wholeSetMealsCount - 1) }
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Icon(Icons.Filled.Remove, contentDescription = "ลดมื้อรวม")
                                            }
                                        }
                                        Text(
                                            text = "$wholeSetMealsCount มื้อ",
                                            fontFamily = PromptFontFamily,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.sp,
                                            color = DeepOlive
                                        )
                                        Surface(
                                            shape = CircleShape,
                                            color = SoftOliveBg,
                                            modifier = Modifier
                                                .size(36.dp)
                                                .clip(CircleShape)
                                                .clickable { onSetWholeSetMealsCount(wholeSetMealsCount + 1) }
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Icon(Icons.Filled.Add, contentDescription = "เพิ่มมื้อรวม", tint = DeepOlive)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                items(workingIngredients, key = { it.id }) { ing ->
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                        border = BorderStroke(1.dp, SageBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = ing.name,
                                    fontFamily = PromptFontFamily,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 15.sp,
                                    color = CharcoalText
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text(
                                        text = FormatUtils.formatBaht(ing.cost),
                                        fontFamily = MontserratFontFamily,
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 13.sp,
                                        color = DeepOlive
                                    )
                                    if (ing.sourceReceiptName.isNotBlank()) {
                                        Text(
                                            text = "· ${ing.sourceReceiptName}",
                                            fontFamily = PromptFontFamily,
                                            fontSize = 12.sp,
                                            color = MutedOliveText
                                        )
                                    }
                                }
                            }

                            if (!useWholeSetMeals) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Surface(
                                        shape = CircleShape,
                                        color = SoftSage,
                                        modifier = Modifier
                                            .size(32.dp)
                                            .clip(CircleShape)
                                            .clickable {
                                                onUpdateIngredientMeals(ing.id, ing.estimatedMeals - 1)
                                            }
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                Icons.Filled.Remove,
                                                contentDescription = "ลดมื้อ",
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                    Text(
                                        text = "${ing.estimatedMeals} มื้อ",
                                        fontFamily = PromptFontFamily,
                                        fontWeight = FontWeight.Medium,
                                        fontSize = 13.sp,
                                        modifier = Modifier.padding(horizontal = 4.dp)
                                    )
                                    Surface(
                                        shape = CircleShape,
                                        color = SoftOliveBg,
                                        modifier = Modifier
                                            .size(32.dp)
                                            .clip(CircleShape)
                                            .clickable {
                                                onUpdateIngredientMeals(ing.id, ing.estimatedMeals + 1)
                                            }
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                Icons.Filled.Add,
                                                contentDescription = "เพิ่มมื้อ",
                                                tint = DeepOlive,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                }
                            }

                            IconButton(onClick = { onRemoveIngredient(ing.id) }) {
                                Icon(
                                    imageVector = Icons.Filled.DeleteOutline,
                                    contentDescription = "ลบวัตถุดิบ",
                                    tint = VibrantOrange,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }

                // Live Meal Calculation Result Card
                item(key = "live_meal_calculation") {
                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                        border = BorderStroke(1.5.dp, OliveGreen),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "ผลคำนวณต้นทุนมื้ออาหาร",
                                fontFamily = PromptFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = DeepOlive
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                MetricBox(
                                    label = "กินได้ทั้งหมด",
                                    value = "$totalMeals มื้อ",
                                    modifier = Modifier.weight(1f)
                                )
                                MetricBox(
                                    label = "กินได้นาน",
                                    value = "${FormatUtils.formatCompact(estimatedDays)} วัน",
                                    modifier = Modifier.weight(1f)
                                )
                                MetricBox(
                                    label = "เฉลี่ยมื้อละ",
                                    value = FormatUtils.formatBaht(costPerMeal),
                                    highlight = true,
                                    modifier = Modifier.weight(1.2f)
                                )
                            }
                            Spacer(modifier = Modifier.height(14.dp))
                            Button(
                                onClick = { showSaveTitleDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = VibrantOrange),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("save_meal_plan_button")
                            ) {
                                Icon(Icons.Filled.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "สรุปมื้ออาหาร (บันทึกการ์ด)",
                                    fontFamily = PromptFontFamily,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }
            } else {
                item(key = "meal_workspace_empty") {
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                        border = BorderStroke(1.dp, SageBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Filled.RestaurantMenu,
                                contentDescription = null,
                                tint = OliveGreen,
                                modifier = Modifier.size(34.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "เริ่มคำนวณต้นทุนต่อมื้อ",
                                fontFamily = PromptFontFamily,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 15.sp,
                                color = CharcoalText
                            )
                            Text(
                                text = "กด \"ดึงจากใบเสร็จ\" หรือ \"+ เพิ่มวัตถุดิบเอง\" เพื่อแบ่งจำนวนมื้อและหารเฉลี่ยราคา",
                                fontFamily = PromptFontFamily,
                                fontSize = 12.sp,
                                color = MutedOliveText
                            )
                        }
                    }
                }
            }

            // 4. Saved Meal Summary Cards (Receipt Style)
            if (savedMealPlans.isNotEmpty()) {
                item(key = "saved_plans_header") {
                    Text(
                        text = "ประวัติการ์ดสรุปมื้ออาหาร (${savedMealPlans.size})",
                        fontFamily = PromptFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = DeepOlive,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                }

                items(savedMealPlans, key = { it.entity.id }) { plan ->
                    SavedMealPlanReceiptCard(
                        plan = plan,
                        onDelete = { onDeleteMealPlan(plan.entity.id) }
                    )
                }
            }

            item { Spacer(modifier = Modifier.height(16.dp)) }
        }
    }

    if (showReceiptPicker) {
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(
            onDismissRequest = { showReceiptPicker = false },
            sheetState = sheetState,
            containerColor = SurfaceWhite
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .padding(bottom = 28.dp)
            ) {
                Text(
                    text = "เลือกใบเสร็จที่ต้องการนำเข้า",
                    fontFamily = PromptFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = DeepOlive
                )
                Spacer(modifier = Modifier.height(12.dp))
                if (receipts.isEmpty()) {
                    Text(
                        text = "ยังไม่มีใบเสร็จที่บันทึกไว้ในเมนู Receipt",
                        fontFamily = PromptFontFamily,
                        fontSize = 14.sp,
                        color = MutedOliveText
                    )
                } else {
                    receipts.forEach { receipt ->
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = MintBackground,
                            border = BorderStroke(1.dp, SageBorder),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .clickable {
                                    onImportFromReceipt(receipt)
                                    showReceiptPicker = false
                                }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = receipt.entity.storeName,
                                        fontFamily = PromptFontFamily,
                                        fontWeight = FontWeight.SemiBold,
                                        color = CharcoalText
                                    )
                                    Text(
                                        text = "${FormatUtils.formatThaiDate(receipt.entity.purchaseDateMillis)} · ${receipt.items.size} รายการ",
                                        fontFamily = PromptFontFamily,
                                        fontSize = 12.sp,
                                        color = MutedOliveText
                                    )
                                }
                                Text(
                                    text = FormatUtils.formatBaht(receipt.entity.grandTotal),
                                    fontFamily = MontserratFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    color = VibrantOrange
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showManualDialog) {
        AddManualIngredientDialog(
            onDismiss = { showManualDialog = false },
            onAdd = { name, cost, meals ->
                onAddManualIngredient(name, cost, meals)
                showManualDialog = false
            }
        )
    }

    if (showSaveTitleDialog) {
        var titleInput by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showSaveTitleDialog = false },
            containerColor = SurfaceWhite,
            title = {
                Text(
                    text = "บันทึกสรุปมื้ออาหาร",
                    fontFamily = PromptFontFamily,
                    fontWeight = FontWeight.Bold,
                    color = DeepOlive
                )
            },
            text = {
                OutlinedTextField(
                    value = titleInput,
                    onValueChange = { titleInput = it },
                    label = { Text("ชื่อชุดอาหาร (ไม่บังคับ)", fontFamily = PromptFontFamily) },
                    placeholder = { Text("เช่น ข้าวกล่องไก่ผัดพริกแกง", fontFamily = PromptFontFamily) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onSaveMealPlanSummary(titleInput)
                        showSaveTitleDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = OliveGreen),
                    modifier = Modifier.testTag("confirm_save_meal_plan")
                ) {
                    Text("บันทึก", fontFamily = PromptFontFamily)
                }
            },
            dismissButton = {
                TextButton(onClick = { showSaveTitleDialog = false }) {
                    Text("ยกเลิก", fontFamily = PromptFontFamily, color = MutedOliveText)
                }
            }
        )
    }
}

@Composable
private fun MetricBox(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    highlight: Boolean = false
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = if (highlight) SoftOrangeBg else MintBackground,
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = label,
                fontFamily = PromptFontFamily,
                fontSize = 11.sp,
                color = MutedOliveText
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = value,
                fontFamily = MontserratFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = if (highlight) VibrantOrange else DeepOlive,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun SavedMealPlanReceiptCard(
    plan: MealPlanUiModel,
    onDelete: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
        border = BorderStroke(1.dp, DeepOlive.copy(alpha = 0.4f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    MueLaLogo(size = 24.dp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = plan.entity.title,
                        fontFamily = PromptFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = CharcoalText,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                IconButton(onClick = onDelete) {
                    Icon(
                        imageVector = Icons.Filled.DeleteOutline,
                        contentDescription = "ลบสรุปมื้ออาหาร",
                        tint = VibrantOrange,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            DashedReceiptDivider(modifier = Modifier.padding(vertical = 8.dp))

            plan.ingredients.forEach { ing ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 2.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "• ${ing.name}",
                        fontFamily = PromptFontFamily,
                        fontSize = 13.sp,
                        color = CharcoalText
                    )
                    Text(
                        text = FormatUtils.formatBaht(ing.cost),
                        fontFamily = MontserratFontFamily,
                        fontSize = 13.sp,
                        color = MutedOliveText
                    )
                }
            }

            DashedReceiptDivider(modifier = Modifier.padding(vertical = 8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "รวม ${FormatUtils.formatBaht(plan.entity.totalCost)} · ${plan.entity.totalMeals} มื้อ",
                        fontFamily = PromptFontFamily,
                        fontSize = 12.sp,
                        color = MutedOliveText
                    )
                    Text(
                        text = "อยู่ได้ ${FormatUtils.formatCompact(plan.entity.estimatedDays)} วัน (${plan.entity.mealsPerDay} มื้อ/วัน)",
                        fontFamily = PromptFontFamily,
                        fontSize = 12.sp,
                        color = DeepOlive,
                        fontWeight = FontWeight.Medium
                    )
                }
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = SoftOrangeBg
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        horizontalAlignment = Alignment.End
                    ) {
                        Text(
                            text = "เฉลี่ยมื้อละ",
                            fontFamily = PromptFontFamily,
                            fontSize = 10.sp,
                            color = MutedOliveText
                        )
                        Text(
                            text = FormatUtils.formatBaht(plan.entity.costPerMeal),
                            fontFamily = MontserratFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = VibrantOrange
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AddManualIngredientDialog(
    onDismiss: () -> Unit,
    onAdd: (name: String, cost: Double, meals: Int) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var costText by remember { mutableStateOf("") }
    var mealsText by remember { mutableStateOf("2") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = SurfaceWhite,
        title = {
            Text(
                text = "เพิ่มวัตถุดิบด้วยตัวเอง",
                fontFamily = PromptFontFamily,
                fontWeight = FontWeight.Bold,
                color = DeepOlive
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = {
                        name = it
                        errorMsg = null
                    },
                    label = { Text("ชื่อวัตถุดิบ", fontFamily = PromptFontFamily) },
                    singleLine = true
                )
                OutlinedTextField(
                    value = costText,
                    onValueChange = {
                        costText = it
                        errorMsg = null
                    },
                    label = { Text("ราคา / ต้นทุน (บาท)", fontFamily = PromptFontFamily) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                )
                OutlinedTextField(
                    value = mealsText,
                    onValueChange = {
                        mealsText = it
                        errorMsg = null
                    },
                    label = { Text("จำนวนมื้อที่แบ่งกินได้", fontFamily = PromptFontFamily) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                if (errorMsg != null) {
                    Text(
                        text = errorMsg!!,
                        fontFamily = PromptFontFamily,
                        fontSize = 12.sp,
                        color = VibrantOrange
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val c = costText.toDoubleOrNull() ?: -1.0
                    val m = mealsText.toIntOrNull() ?: 0
                    when {
                        name.isBlank() -> errorMsg = "กรุณากรอกชื่อวัตถุดิบ"
                        c < 0.0 -> errorMsg = "กรุณากรอกราคาให้ถูกต้อง"
                        m < 1 -> errorMsg = "จำนวนมื้อต้องอย่างน้อย 1 มื้อ"
                        else -> onAdd(name.trim(), c, m)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = OliveGreen)
            ) {
                Text("เพิ่ม", fontFamily = PromptFontFamily)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("ยกเลิก", fontFamily = PromptFontFamily, color = MutedOliveText)
            }
        }
    )
}
