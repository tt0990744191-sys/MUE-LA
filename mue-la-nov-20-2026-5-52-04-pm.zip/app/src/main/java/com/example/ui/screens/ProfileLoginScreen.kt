package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.local.ProfileEntity
import com.example.ui.components.MueLaLogo
import com.example.ui.theme.CharcoalText
import com.example.ui.theme.DeepOlive
import com.example.ui.theme.MintBackground
import com.example.ui.theme.MontserratFontFamily
import com.example.ui.theme.MutedOliveText
import com.example.ui.theme.OliveGreen
import com.example.ui.theme.ProfileColorPalette
import com.example.ui.theme.PromptFontFamily
import com.example.ui.theme.SageBorder
import com.example.ui.theme.SoftOliveBg
import com.example.ui.theme.SoftOrangeBg
import com.example.ui.theme.SurfaceWhite
import com.example.ui.theme.VibrantOrange

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileLoginScreen(
    profiles: List<ProfileEntity>,
    onVerifyPinAndLogin: (ProfileEntity, String) -> Boolean,
    onCreateProfile: (name: String, colorHex: Long, pin: String) -> Unit,
    onUpdateProfile: (profile: ProfileEntity, name: String, colorHex: Long, pin: String) -> Unit
) {
    var selectedProfileForPin by remember { mutableStateOf<ProfileEntity?>(null) }
    var editingProfile by remember { mutableStateOf<ProfileEntity?>(null) }
    var showAddProfileSheet by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MintBackground)
            .windowInsetsPadding(WindowInsets.safeDrawing),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 560.dp)
                .padding(horizontal = 20.dp, vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(12.dp))
            MueLaLogo(size = 64.dp)
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "MUE LA",
                fontFamily = MontserratFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 30.sp,
                color = DeepOlive,
                letterSpacing = 1.5.sp
            )
            Text(
                text = "เลือกโปรไฟล์ผู้ใช้งาน",
                fontFamily = PromptFontFamily,
                fontWeight = FontWeight.Medium,
                fontSize = 16.sp,
                color = MutedOliveText
            )
            Spacer(modifier = Modifier.height(28.dp))

            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 136.dp),
                contentPadding = PaddingValues(bottom = 24.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(profiles, key = { it.id }) { profile ->
                    ProfileTileCard(
                        profile = profile,
                        onClick = { selectedProfileForPin = profile },
                        onEditClick = { editingProfile = profile }
                    )
                }
                item(key = "add_profile_tile") {
                    AddProfileTileCard(
                        onClick = { showAddProfileSheet = true }
                    )
                }
            }
        }
    }

    selectedProfileForPin?.let { profile ->
        PinEntryDialog(
            profile = profile,
            onDismiss = { selectedProfileForPin = null },
            onVerifyPin = { enteredPin ->
                onVerifyPinAndLogin(profile, enteredPin)
            }
        )
    }

    if (showAddProfileSheet) {
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(
            onDismissRequest = { showAddProfileSheet = false },
            sheetState = sheetState,
            containerColor = SurfaceWhite
        ) {
            ProfileFormSheetContent(
                title = "เพิ่มโปรไฟล์ใหม่",
                subtitle = "ข้อมูลตะกร้า ใบเสร็จ และมื้ออาหารจะแยกจัดเก็บตามโปรไฟล์",
                submitLabel = "สร้างโปรไฟล์",
                initialName = "",
                initialColor = ProfileColorPalette.first(),
                initialPin = "",
                onCancel = { showAddProfileSheet = false },
                onSave = { name, colorHex, pin ->
                    onCreateProfile(name, colorHex, pin)
                    showAddProfileSheet = false
                }
            )
        }
    }

    editingProfile?.let { profile ->
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(
            onDismissRequest = { editingProfile = null },
            sheetState = sheetState,
            containerColor = SurfaceWhite
        ) {
            ProfileFormSheetContent(
                title = "แก้ไขโปรไฟล์",
                subtitle = "เปลี่ยนชื่อ สีประจำโปรไฟล์ หรือรหัส PIN 4 หลัก",
                submitLabel = "บันทึกการแก้ไข",
                initialName = profile.name,
                initialColor = profile.colorHex,
                initialPin = profile.pin,
                onCancel = { editingProfile = null },
                onSave = { name, colorHex, pin ->
                    onUpdateProfile(profile, name, colorHex, pin)
                    editingProfile = null
                }
            )
        }
    }
}

@Composable
private fun ProfileTileCard(
    profile: ProfileEntity,
    onClick: () -> Unit,
    onEditClick: () -> Unit
) {
    val profileColor = Color(profile.colorHex)
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
        border = BorderStroke(1.5.dp, profileColor.copy(alpha = 0.65f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .testTag("profile_card_${profile.id}")
    ) {
        Box(modifier = Modifier.fillMaxWidth()) {
            // Top-right edit button
            IconButton(
                onClick = onEditClick,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(4.dp)
                    .testTag("edit_profile_${profile.id}")
            ) {
                Icon(
                    imageVector = Icons.Filled.Edit,
                    contentDescription = "แก้ไขชื่อโปรไฟล์ ${profile.name}",
                    tint = MutedOliveText,
                    modifier = Modifier.size(18.dp)
                )
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 18.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(66.dp)
                        .clip(CircleShape)
                        .background(profileColor),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = profile.name.firstOrNull()?.uppercase() ?: "M",
                        fontFamily = MontserratFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 28.sp,
                        color = Color.White
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = profile.name,
                    fontFamily = PromptFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = CharcoalText,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.Lock,
                        contentDescription = "ล็อกด้วย PIN",
                        tint = MutedOliveText,
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (profile.isDefaultSeed && profile.pin == "1808") "PIN: 1808" else "PIN 4 หลัก",
                        fontFamily = MontserratFontFamily,
                        fontSize = 12.sp,
                        color = MutedOliveText
                    )
                }
            }
        }
    }
}

@Composable
private fun AddProfileTileCard(
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = SoftOliveBg.copy(alpha = 0.55f)),
        border = BorderStroke(1.5.dp, OliveGreen.copy(alpha = 0.5f)),
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .testTag("add_profile_button")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(SurfaceWhite)
                    .border(1.5.dp, OliveGreen, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.Add,
                    contentDescription = "เพิ่มโปรไฟล์ใหม่",
                    tint = DeepOlive,
                    modifier = Modifier.size(30.dp)
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "+ เพิ่มโปรไฟล์",
                fontFamily = PromptFontFamily,
                fontWeight = FontWeight.SemiBold,
                fontSize = 15.sp,
                color = DeepOlive,
                maxLines = 1
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "ตั้งชื่อ & PIN",
                fontFamily = PromptFontFamily,
                fontSize = 11.sp,
                color = MutedOliveText
            )
        }
    }
}

@Composable
private fun PinEntryDialog(
    profile: ProfileEntity,
    onDismiss: () -> Unit,
    onVerifyPin: (String) -> Boolean
) {
    var enteredPin by remember { mutableStateOf("") }
    var isError by remember { mutableStateOf(false) }

    fun appendDigit(digit: String) {
        if (enteredPin.length >= 4) return
        isError = false
        val next = enteredPin + digit
        enteredPin = next
        if (next.length == 4) {
            val ok = onVerifyPin(next)
            if (!ok) {
                isError = true
                enteredPin = ""
            }
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = SurfaceWhite,
            border = BorderStroke(1.dp, SageBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("pin_dialog_close")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Close,
                            contentDescription = "ปิดหน้าต่าง PIN",
                            tint = MutedOliveText
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(Color(profile.colorHex)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = profile.name.firstOrNull()?.uppercase() ?: "M",
                        fontFamily = MontserratFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 22.sp,
                        color = Color.White
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = profile.name,
                    fontFamily = PromptFontFamily,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 18.sp,
                    color = CharcoalText
                )
                Text(
                    text = "กรอกรหัส PIN 4 หลัก",
                    fontFamily = PromptFontFamily,
                    fontSize = 13.sp,
                    color = MutedOliveText
                )

                Spacer(modifier = Modifier.height(16.dp))

                // 4 PIN Dots
                Row(
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    repeat(4) { index ->
                        val filled = index < enteredPin.length
                        Box(
                            modifier = Modifier
                                .size(18.dp)
                                .clip(CircleShape)
                                .background(
                                    when {
                                        isError -> VibrantOrange.copy(alpha = 0.25f)
                                        filled -> OliveGreen
                                        else -> MintBackground
                                    }
                                )
                                .border(
                                    width = 1.5.dp,
                                    color = if (isError) VibrantOrange else if (filled) DeepOlive else SageBorder,
                                    shape = CircleShape
                                )
                        )
                    }
                }

                AnimatedVisibility(
                    visible = isError,
                    enter = fadeIn(tween(150)),
                    exit = fadeOut(tween(150))
                ) {
                    Text(
                        text = "รหัส PIN ไม่ถูกต้อง กรุณาลองใหม่",
                        fontFamily = PromptFontFamily,
                        fontSize = 12.sp,
                        color = VibrantOrange,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Tactile Numeric Keypad
                val rows = listOf(
                    listOf("1", "2", "3"),
                    listOf("4", "5", "6"),
                    listOf("7", "8", "9"),
                    listOf("C", "0", "DEL")
                )
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    rows.forEach { row ->
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            row.forEach { key ->
                                when (key) {
                                    "C" -> {
                                        Surface(
                                            shape = CircleShape,
                                            color = SoftOrangeBg,
                                            modifier = Modifier
                                                .size(62.dp)
                                                .clip(CircleShape)
                                                .clickable {
                                                    enteredPin = ""
                                                    isError = false
                                                }
                                                .testTag("pin_key_clear")
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Text(
                                                    text = "ล้าง",
                                                    fontFamily = PromptFontFamily,
                                                    fontSize = 13.sp,
                                                    fontWeight = FontWeight.Medium,
                                                    color = VibrantOrange
                                                )
                                            }
                                        }
                                    }
                                    "DEL" -> {
                                        Surface(
                                            shape = CircleShape,
                                            color = MintBackground,
                                            modifier = Modifier
                                                .size(62.dp)
                                                .clip(CircleShape)
                                                .clickable {
                                                    if (enteredPin.isNotEmpty()) {
                                                        enteredPin = enteredPin.dropLast(1)
                                                    }
                                                }
                                                .testTag("pin_key_backspace")
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Icon(
                                                    imageVector = Icons.AutoMirrored.Filled.Backspace,
                                                    contentDescription = "ลบตัวเลข",
                                                    tint = DeepOlive,
                                                    modifier = Modifier.size(20.dp)
                                                )
                                            }
                                        }
                                    }
                                    else -> {
                                        Surface(
                                            shape = CircleShape,
                                            color = MintBackground,
                                            border = BorderStroke(1.dp, SageBorder),
                                            modifier = Modifier
                                                .size(62.dp)
                                                .clip(CircleShape)
                                                .clickable { appendDigit(key) }
                                                .testTag("pin_key_$key")
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Text(
                                                    text = key,
                                                    fontFamily = MontserratFontFamily,
                                                    fontWeight = FontWeight.SemiBold,
                                                    fontSize = 22.sp,
                                                    color = CharcoalText
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ProfileFormSheetContent(
    title: String,
    subtitle: String,
    submitLabel: String,
    initialName: String,
    initialColor: Long,
    initialPin: String,
    onCancel: () -> Unit,
    onSave: (name: String, colorHex: Long, pin: String) -> Unit
) {
    var name by remember { mutableStateOf(initialName) }
    var pin by remember { mutableStateOf(initialPin) }
    var selectedColor by remember { mutableStateOf(initialColor) }
    var validationError by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
            .padding(bottom = 28.dp)
    ) {
        Text(
            text = title,
            fontFamily = PromptFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 20.sp,
            color = DeepOlive
        )
        Text(
            text = subtitle,
            fontFamily = PromptFontFamily,
            fontSize = 13.sp,
            color = MutedOliveText
        )
        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = name,
            onValueChange = {
                name = it
                validationError = null
            },
            label = { Text("ชื่อโปรไฟล์", fontFamily = PromptFontFamily) },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("new_profile_name_input"),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = OliveGreen,
                focusedLabelColor = DeepOlive
            )
        )

        Spacer(modifier = Modifier.height(14.dp))

        Text(
            text = "สีประจำโปรไฟล์",
            fontFamily = PromptFontFamily,
            fontWeight = FontWeight.Medium,
            fontSize = 14.sp,
            color = CharcoalText
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            ProfileColorPalette.forEach { hex ->
                val selected = hex == selectedColor
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(Color(hex))
                        .border(
                            width = if (selected) 3.dp else 0.dp,
                            color = if (selected) CharcoalText else Color.Transparent,
                            shape = CircleShape
                        )
                        .clickable { selectedColor = hex }
                        .testTag("profile_color_${hex}"),
                    contentAlignment = Alignment.Center
                ) {
                    if (selected) {
                        Icon(
                            imageVector = Icons.Filled.Check,
                            contentDescription = "เลือกสีนี้",
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        OutlinedTextField(
            value = pin,
            onValueChange = { input ->
                val digitsOnly = input.filter { it.isDigit() }.take(4)
                pin = digitsOnly
                validationError = null
            },
            label = { Text("รหัส PIN 4 หลัก", fontFamily = PromptFontFamily) },
            placeholder = { Text("เช่น 1234", fontFamily = MontserratFontFamily) },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("new_profile_pin_input"),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = OliveGreen,
                focusedLabelColor = DeepOlive
            )
        )

        if (validationError != null) {
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = validationError!!,
                fontFamily = PromptFontFamily,
                fontSize = 12.sp,
                color = VibrantOrange,
                textAlign = TextAlign.Start
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            TextButton(
                onClick = onCancel,
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
            ) {
                Text("ยกเลิก", fontFamily = PromptFontFamily, color = MutedOliveText)
            }
            Button(
                onClick = {
                    when {
                        name.isBlank() -> validationError = "กรุณากรอกชื่อโปรไฟล์"
                        pin.length != 4 -> validationError = "กรุณากรอกรหัส PIN ให้ครบ 4 หลัก"
                        else -> onSave(name.trim(), selectedColor, pin)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = OliveGreen),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .weight(2f)
                    .height(48.dp)
                    .testTag("save_new_profile_button")
            ) {
                Text(
                    text = submitLabel,
                    fontFamily = PromptFontFamily,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White
                )
            }
        }
    }
}
