package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.RestaurantMenu
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material.icons.outlined.RestaurantMenu
import androidx.compose.material.icons.outlined.ShoppingCart
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.ProfileEntity
import com.example.data.model.MueLaTab
import com.example.ui.theme.CharcoalText
import com.example.ui.theme.DeepOlive
import com.example.ui.theme.MintBackground
import com.example.ui.theme.MontserratFontFamily
import com.example.ui.theme.MutedOliveText
import com.example.ui.theme.OliveGreen
import com.example.ui.theme.PromptFontFamily
import com.example.ui.theme.SageBorder
import com.example.ui.theme.SoftOliveBg
import com.example.ui.theme.SurfaceWhite
import com.example.ui.theme.VibrantOrange

/**
 * Minimalist geometric brand mark combining a dining bowl and rising portion/budget bars
 * using #7D8D39, #5B6E2C, and #FF5A22.
 */
@Composable
fun MueLaLogo(
    modifier: Modifier = Modifier,
    size: Dp = 40.dp
) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height

        // Rising chart bars inside/above the bowl
        val barWidth = w * 0.13f
        val barGap = w * 0.06f
        val startX = w * 0.25f

        // Bar 1 (Olive Green)
        drawRoundRect(
            color = OliveGreen,
            topLeft = Offset(startX, h * 0.28f),
            size = Size(barWidth, h * 0.24f),
            cornerRadius = CornerRadius(w * 0.04f, w * 0.04f)
        )

        // Bar 2 (Deep Olive)
        drawRoundRect(
            color = DeepOlive,
            topLeft = Offset(startX + barWidth + barGap, h * 0.16f),
            size = Size(barWidth, h * 0.36f),
            cornerRadius = CornerRadius(w * 0.04f, w * 0.04f)
        )

        // Bar 3 (Vibrant Orange accent)
        drawRoundRect(
            color = VibrantOrange,
            topLeft = Offset(startX + (barWidth + barGap) * 2f, h * 0.08f),
            size = Size(barWidth, h * 0.44f),
            cornerRadius = CornerRadius(w * 0.04f, w * 0.04f)
        )

        // Minimalist Bowl Curve
        val bowlPath = Path().apply {
            moveTo(w * 0.14f, h * 0.54f)
            lineTo(w * 0.86f, h * 0.54f)
            cubicTo(
                w * 0.85f, h * 0.84f,
                w * 0.65f, h * 0.88f,
                w * 0.50f, h * 0.88f
            )
            cubicTo(
                w * 0.35f, h * 0.88f,
                w * 0.15f, h * 0.84f,
                w * 0.14f, h * 0.54f
            )
            close()
        }

        drawPath(
            path = bowlPath,
            color = DeepOlive,
            style = Stroke(
                width = w * 0.085f,
                cap = StrokeCap.Round,
                join = StrokeJoin.Round
            )
        )

        // Bowl base foot
        drawLine(
            color = OliveGreen,
            start = Offset(w * 0.37f, h * 0.93f),
            end = Offset(w * 0.63f, h * 0.93f),
            strokeWidth = w * 0.07f,
            cap = StrokeCap.Round
        )

        // Orange portion divider dot inside bowl
        drawCircle(
            color = VibrantOrange,
            radius = w * 0.055f,
            center = Offset(w * 0.64f, h * 0.70f)
        )
    }
}

@Composable
fun MueLaTopBar(
    activeTab: MueLaTab,
    activeProfile: ProfileEntity,
    onSwitchProfileClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val profileColor = Color(activeProfile.colorHex)
    Surface(
        color = MintBackground,
        modifier = modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.statusBars)
    ) {
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    MueLaLogo(size = 34.dp)
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "MUE LA",
                            fontFamily = MontserratFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = DeepOlive,
                            letterSpacing = 0.6.sp
                        )
                        Text(
                            text = "${activeTab.titleEn} · ${activeTab.titleTh}",
                            fontFamily = PromptFontFamily,
                            fontSize = 12.sp,
                            color = MutedOliveText,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                // Switch Profile Button (minimum 48dp touch target)
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = SurfaceWhite,
                    border = BorderStroke(1.dp, SageBorder),
                    modifier = Modifier
                        .height(48.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .clickable(onClick = onSwitchProfileClick)
                        .testTag("switch_profile_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Filled.SwapHoriz,
                            contentDescription = "สลับโปรไฟล์",
                            tint = DeepOlive,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "สลับโปรไฟล์",
                            fontFamily = PromptFontFamily,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = DeepOlive
                        )
                    }
                }
            }

            // Prominent Active Profile Identity Strip
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = SurfaceWhite,
                border = BorderStroke(1.5.dp, profileColor.copy(alpha = 0.55f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .padding(bottom = 8.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(26.dp)
                            .clip(CircleShape)
                            .background(profileColor),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = activeProfile.name.firstOrNull()?.uppercase() ?: "M",
                            color = Color.White,
                            fontFamily = MontserratFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "หน้าจอของ:",
                        fontFamily = PromptFontFamily,
                        fontSize = 12.sp,
                        color = MutedOliveText
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = activeProfile.name,
                        fontFamily = PromptFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = CharcoalText,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            HorizontalDivider(color = SageBorder, thickness = 1.dp)
        }
    }
}

@Composable
fun MueLaBottomBar(
    activeTab: MueLaTab,
    selectedCartCount: Int,
    onSelectTab: (MueLaTab) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = SurfaceWhite,
        tonalElevation = 2.dp,
        shadowElevation = 6.dp,
        modifier = modifier.fillMaxWidth()
    ) {
        Column {
            HorizontalDivider(color = SageBorder, thickness = 1.dp)
            NavigationBar(
                containerColor = SurfaceWhite,
                contentColor = DeepOlive,
                windowInsets = WindowInsets.navigationBars,
                tonalElevation = 0.dp
            ) {
                MueLaTab.entries.forEach { tab ->
                    val isSelected = tab == activeTab
                    val icon = when (tab) {
                        MueLaTab.LIST_FOOD -> if (isSelected) Icons.Filled.ShoppingCart else Icons.Outlined.ShoppingCart
                        MueLaTab.DIGITAL_RECEIPT -> if (isSelected) Icons.Filled.ReceiptLong else Icons.Outlined.ReceiptLong
                        MueLaTab.RECEIPT -> if (isSelected) Icons.Filled.History else Icons.Outlined.History
                        MueLaTab.MEAL_NOTE -> if (isSelected) Icons.Filled.RestaurantMenu else Icons.Outlined.RestaurantMenu
                        MueLaTab.WEEKLY_FOOD -> if (isSelected) Icons.Filled.CalendarMonth else Icons.Outlined.CalendarMonth
                    }
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { onSelectTab(tab) },
                        modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}"),
                        icon = {
                            if (tab == MueLaTab.DIGITAL_RECEIPT && selectedCartCount > 0) {
                                BadgedBox(
                                    badge = {
                                        Badge(
                                            containerColor = VibrantOrange,
                                            contentColor = Color.White
                                        ) {
                                            Text(
                                                text = selectedCartCount.toString(),
                                                fontFamily = MontserratFontFamily,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                ) {
                                    Icon(
                                        imageVector = icon,
                                        contentDescription = tab.titleTh
                                    )
                                }
                            } else {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = tab.titleTh
                                )
                            }
                        },
                        label = {
                            Text(
                                text = tab.titleTh,
                                fontFamily = PromptFontFamily,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = DeepOlive,
                            selectedTextColor = DeepOlive,
                            indicatorColor = SoftOliveBg,
                            unselectedIconColor = MutedOliveText,
                            unselectedTextColor = MutedOliveText
                        )
                    )
                }
            }
        }
    }
}

@Composable
fun DashedReceiptDivider(
    modifier: Modifier = Modifier,
    color: Color = SageBorder
) {
    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(2.dp)
    ) {
        drawLine(
            color = color,
            start = Offset(0f, size.height / 2f),
            end = Offset(size.width, size.height / 2f),
            strokeWidth = 2.dp.toPx(),
            pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 10f), 0f)
        )
    }
}
