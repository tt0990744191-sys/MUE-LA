package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand Core Palette
val MintBackground = Color(0xFFE3F0E1)
val OliveGreen = Color(0xFF7D8D39)
val DeepOlive = Color(0xFF5B6E2C)
val VibrantOrange = Color(0xFFFF5A22)

// Supporting Surface & Text Tokens
val SurfaceWhite = Color(0xFFFFFFFF)
val SoftSage = Color(0xFFD4E5D2)
val SageBorder = Color(0xFFBCD3BA)
val CharcoalText = Color(0xFF1E2519)
val MutedOliveText = Color(0xFF4F5E44)
val SoftOrangeBg = Color(0xFFFFEDE6)
val SoftOliveBg = Color(0xFFEEF5E4)

// Profile Avatar Swatch Options
val ProfileColorPalette = listOf(
    0xFF7D8D39L, // Olive Green
    0xFF5B6E2CL, // Deep Olive
    0xFFFF5A22L, // Vibrant Orange
    0xFF2D7D6EL, // Sage Teal
    0xFF3A5A78L, // Slate Blue
    0xFF8C5A3CL, // Warm Terracotta
)
