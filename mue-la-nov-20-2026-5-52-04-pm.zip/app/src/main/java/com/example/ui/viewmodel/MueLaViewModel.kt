package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.CartItemEntity
import com.example.data.local.MealPlanEntity
import com.example.data.local.ProfileEntity
import com.example.data.local.ReceiptEntity
import com.example.data.local.WeeklyHistoryEntity
import com.example.data.model.MealIngredient
import com.example.data.model.MealSlotType
import com.example.data.model.MueLaTab
import com.example.data.model.ReceiptLineItem
import com.example.data.model.RoundingMode
import com.example.data.model.WeeklyDayRecord
import com.example.data.model.WeeklyMealEntry
import com.example.data.repository.MueLaRepository
import com.example.util.FormatUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID
import kotlin.math.max

data class ReceiptTotals(
    val subtotal: Double,
    val discountApplied: Double,
    val taxableBase: Double,
    val vatAmount: Double,
    val grandTotal: Double
)

data class ReceiptUiModel(
    val entity: ReceiptEntity,
    val items: List<ReceiptLineItem>
)

data class MealPlanUiModel(
    val entity: MealPlanEntity,
    val ingredients: List<MealIngredient>
)

data class WeeklyHistoryUiModel(
    val entity: WeeklyHistoryEntity,
    val days: List<WeeklyDayRecord>
)

data class MueLaUiState(
    val isReady: Boolean = false,
    val profiles: List<ProfileEntity> = emptyList(),
    val activeProfile: ProfileEntity? = null,
    val activeTab: MueLaTab = MueLaTab.LIST_FOOD,
    val cartItems: List<CartItemEntity> = emptyList(),
    val receipts: List<ReceiptUiModel> = emptyList(),
    val mealPlans: List<MealPlanUiModel> = emptyList(),
    val workingMealIngredients: List<MealIngredient> = emptyList(),
    val useWholeSetMeals: Boolean = false,
    val wholeSetMealsCount: Int = 4,
    val activeWeekStartMillis: Long = FormatUtils.startOfCurrentWeekMondayMillis(),
    val activeWeekDays: List<WeeklyDayRecord> = emptyList(),
    val weeklyHistory: List<WeeklyHistoryUiModel> = emptyList()
)

@OptIn(ExperimentalCoroutinesApi::class)
class MueLaViewModel(
    private val repository: MueLaRepository
) : ViewModel() {

    private val _isReady = MutableStateFlow(false)
    private val _activeProfileId = MutableStateFlow<String?>(null)
    private val _activeTab = MutableStateFlow(MueLaTab.LIST_FOOD)

    // Meal Note workspace state
    private val _workingMealIngredients = MutableStateFlow<List<MealIngredient>>(emptyList())
    private val _useWholeSetMeals = MutableStateFlow(false)
    private val _wholeSetMealsCount = MutableStateFlow(4)

    private val _snackbarEvents = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val snackbarEvents: SharedFlow<String> = _snackbarEvents.asSharedFlow()

    private val profilesFlow = repository.observeProfiles()

    private val cartItemsFlow = _activeProfileId.flatMapLatest { pid ->
        if (pid == null) flowOf(emptyList()) else repository.observeCartItems(pid)
    }

    private val receiptsFlow = _activeProfileId.flatMapLatest { pid ->
        if (pid == null) flowOf(emptyList())
        else repository.observeReceipts(pid).map { list ->
            list.map { ReceiptUiModel(it, repository.decodeReceiptItems(it.itemsJson)) }
        }.flowOn(Dispatchers.Default)
    }

    private val mealPlansFlow = _activeProfileId.flatMapLatest { pid ->
        if (pid == null) flowOf(emptyList())
        else repository.observeMealPlans(pid).map { list ->
            list.map { MealPlanUiModel(it, repository.decodeMealIngredients(it.ingredientsJson)) }
        }.flowOn(Dispatchers.Default)
    }

    private val weeklyActiveFlow = _activeProfileId.flatMapLatest { pid ->
        if (pid == null) flowOf(null) else repository.observeWeeklyActive(pid)
    }

    private val weeklyHistoryFlow = _activeProfileId.flatMapLatest { pid ->
        if (pid == null) flowOf(emptyList())
        else repository.observeWeeklyHistory(pid).map { list ->
            list.map {
                WeeklyHistoryUiModel(
                    entity = it,
                    days = repository.decodeWeeklyDays(it.daysJson, it.weekStartDateMillis)
                )
            }
        }.flowOn(Dispatchers.Default)
    }

    private val profileCoreFlow = combine(
        _isReady,
        profilesFlow,
        _activeProfileId,
        _activeTab
    ) { ready, profiles, activeId, tab ->
        Quad(ready, profiles, activeId, tab)
    }

    private val mealWorkspaceFlow = combine(
        _workingMealIngredients,
        _useWholeSetMeals,
        _wholeSetMealsCount
    ) { ingredients, wholeMode, wholeCount ->
        Triple(ingredients, wholeMode, wholeCount)
    }

    val uiState: StateFlow<MueLaUiState> = combine(
        profileCoreFlow,
        cartItemsFlow,
        receiptsFlow,
        mealPlansFlow,
        mealWorkspaceFlow,
        weeklyActiveFlow,
        weeklyHistoryFlow
    ) { values ->
        @Suppress("UNCHECKED_CAST")
        val core = values[0] as Quad<Boolean, List<ProfileEntity>, String?, MueLaTab>
        @Suppress("UNCHECKED_CAST")
        val cart = values[1] as List<CartItemEntity>
        @Suppress("UNCHECKED_CAST")
        val receipts = values[2] as List<ReceiptUiModel>
        @Suppress("UNCHECKED_CAST")
        val mealPlans = values[3] as List<MealPlanUiModel>
        @Suppress("UNCHECKED_CAST")
        val mealWork = values[4] as Triple<List<MealIngredient>, Boolean, Int>
        val weeklyActive = values[5] as com.example.data.local.WeeklyActiveEntity?
        @Suppress("UNCHECKED_CAST")
        val weeklyHistory = values[6] as List<WeeklyHistoryUiModel>

        val activeProfile = core.second.firstOrNull { it.id == core.third }
        val defaultStart = FormatUtils.startOfCurrentWeekMondayMillis()
        val weekStart = weeklyActive?.weekStartDateMillis ?: defaultStart
        val weekDays = if (weeklyActive != null) {
            repository.decodeWeeklyDays(weeklyActive.daysJson, weekStart)
        } else {
            repository.buildEmptyWeek(weekStart)
        }

        MueLaUiState(
            isReady = core.first,
            profiles = core.second,
            activeProfile = activeProfile,
            activeTab = core.fourth,
            cartItems = cart,
            receipts = receipts,
            mealPlans = mealPlans,
            workingMealIngredients = mealWork.first,
            useWholeSetMeals = mealWork.second,
            wholeSetMealsCount = mealWork.third,
            activeWeekStartMillis = weekStart,
            activeWeekDays = weekDays,
            weeklyHistory = weeklyHistory
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = MueLaUiState()
    )

    init {
        viewModelScope.launch {
            repository.ensureDefaultProfileExists()
            _isReady.value = true
        }
    }

    private fun emitMessage(msg: String) {
        _snackbarEvents.tryEmit(msg)
    }

    // --- Profile & PIN Login ---
    fun verifyPinAndLogin(profile: ProfileEntity, enteredPin: String): Boolean {
        return if (profile.pin == enteredPin) {
            _activeProfileId.value = profile.id
            _activeTab.value = MueLaTab.LIST_FOOD
            _workingMealIngredients.value = emptyList()
            true
        } else {
            false
        }
    }

    fun createProfile(name: String, colorHex: Long, pin: String) {
        if (name.isBlank() || pin.length != 4) return
        viewModelScope.launch {
            val created = repository.createProfile(name, colorHex, pin)
            _activeProfileId.value = created.id
            _activeTab.value = MueLaTab.LIST_FOOD
            _workingMealIngredients.value = emptyList()
            emitMessage("สร้างโปรไฟล์ ${created.name} เรียบร้อย")
        }
    }

    fun updateProfileDetails(profile: ProfileEntity, name: String, colorHex: Long, pin: String) {
        if (name.isBlank() || pin.length != 4) return
        viewModelScope.launch {
            repository.updateProfile(
                profile.copy(
                    name = name.trim(),
                    colorHex = colorHex,
                    pin = pin
                )
            )
            emitMessage("อัปเดตโปรไฟล์ ${name.trim()} แล้ว")
        }
    }

    fun switchProfileLogout() {
        _activeProfileId.value = null
        _workingMealIngredients.value = emptyList()
    }

    fun selectTab(tab: MueLaTab) {
        _activeTab.value = tab
    }

    // --- Menu 1: List Food ---
    fun updateBudgetLimit(newBudget: Double) {
        val profile = uiState.value.activeProfile ?: return
        val safeBudget = max(0.0, newBudget)
        viewModelScope.launch {
            repository.updateProfile(profile.copy(budgetLimit = safeBudget))
            emitMessage("อัปเดตงบประมาณเป็น ${FormatUtils.formatBaht(safeBudget)}")
        }
    }

    fun addCartItem(
        name: String,
        category: String,
        unit: String,
        isWeighted: Boolean,
        weightKg: Double,
        pricePerKg: Double,
        roundingMode: RoundingMode,
        quantity: Double,
        unitPrice: Double
    ) {
        val profileId = _activeProfileId.value ?: return
        val trimmedName = name.trim()
        if (trimmedName.isEmpty()) return

        val finalQty: Double
        val finalUnitPrice: Double
        if (isWeighted) {
            val rawPrice = max(0.0, weightKg) * max(0.0, pricePerKg)
            finalUnitPrice = FormatUtils.roundThaiRetail(rawPrice, roundingMode)
            finalQty = 1.0
        } else {
            finalQty = max(0.1, quantity)
            finalUnitPrice = max(0.0, unitPrice)
        }

        viewModelScope.launch {
            repository.insertCartItem(
                CartItemEntity(
                    id = UUID.randomUUID().toString(),
                    profileId = profileId,
                    name = trimmedName,
                    category = category,
                    unit = unit,
                    isWeighted = isWeighted,
                    weightKg = if (isWeighted) weightKg else 0.0,
                    pricePerKg = if (isWeighted) pricePerKg else 0.0,
                    roundingMode = roundingMode.name,
                    quantity = finalQty,
                    unitPrice = finalUnitPrice,
                    isSelected = true
                )
            )
            emitMessage("เพิ่ม $trimmedName ลงตะกร้าแล้ว")
        }
    }

    fun toggleCartItemSelected(item: CartItemEntity) {
        viewModelScope.launch {
            repository.updateCartItem(item.copy(isSelected = !item.isSelected))
        }
    }

    fun setAllCartItemsSelected(selected: Boolean) {
        val profileId = _activeProfileId.value ?: return
        viewModelScope.launch {
            repository.setAllCartItemsSelected(profileId, selected)
        }
    }

    fun updateCartItemQuantityAndPrice(item: CartItemEntity, newQty: Double, newUnitPrice: Double) {
        viewModelScope.launch {
            repository.updateCartItem(
                item.copy(
                    quantity = max(0.1, newQty),
                    unitPrice = max(0.0, newUnitPrice)
                )
            )
        }
    }

    fun deleteCartItem(id: String) {
        viewModelScope.launch {
            repository.deleteCartItem(id)
        }
    }

    // --- Menu 2 & 3: Digital Receipt & Receipt History ---
    fun issueDigitalReceipt(
        storeName: String,
        purchaseDateMillis: Long,
        includeVat: Boolean,
        discountAmount: Double,
        discountBeforeVat: Boolean
    ) {
        val profileId = _activeProfileId.value ?: return
        val selectedItems = uiState.value.cartItems.filter { it.isSelected }
        if (selectedItems.isEmpty()) {
            emitMessage("กรุณาเลือกรายการสินค้าในตะกร้าก่อนออกใบเสร็จ")
            return
        }

        val lineItems = selectedItems.map { cart ->
            ReceiptLineItem(
                id = cart.id,
                name = cart.name,
                category = cart.category,
                unit = cart.unit,
                quantity = cart.quantity,
                unitPrice = cart.unitPrice,
                isWeighted = cart.isWeighted,
                weightKg = cart.weightKg,
                pricePerKg = cart.pricePerKg
            )
        }

        val totals = calculateReceiptTotals(
            items = lineItems,
            includeVat = includeVat,
            discountAmount = discountAmount,
            discountBeforeVat = discountBeforeVat
        )

        val cleanStore = storeName.trim().ifEmpty { "ร้านค้าทั่วไป" }

        viewModelScope.launch {
            repository.saveReceiptAndClearSelected(
                ReceiptEntity(
                    id = UUID.randomUUID().toString(),
                    profileId = profileId,
                    storeName = cleanStore,
                    purchaseDateMillis = FormatUtils.startOfDayMillis(purchaseDateMillis),
                    itemsJson = repository.encodeReceiptItems(lineItems),
                    subtotal = totals.subtotal,
                    includeVat = includeVat,
                    vatAmount = totals.vatAmount,
                    discountAmount = totals.discountApplied,
                    discountBeforeVat = discountBeforeVat,
                    grandTotal = totals.grandTotal
                )
            )
            emitMessage("บันทึกใบเสร็จ $cleanStore เรียบร้อย")
            _activeTab.value = MueLaTab.RECEIPT
        }
    }

    fun updateExistingReceipt(
        original: ReceiptEntity,
        storeName: String,
        purchaseDateMillis: Long,
        items: List<ReceiptLineItem>,
        includeVat: Boolean,
        discountAmount: Double,
        discountBeforeVat: Boolean
    ) {
        val totals = calculateReceiptTotals(items, includeVat, discountAmount, discountBeforeVat)
        val cleanStore = storeName.trim().ifEmpty { "ร้านค้าทั่วไป" }
        viewModelScope.launch {
            repository.updateReceipt(
                original.copy(
                    storeName = cleanStore,
                    purchaseDateMillis = FormatUtils.startOfDayMillis(purchaseDateMillis),
                    itemsJson = repository.encodeReceiptItems(items),
                    subtotal = totals.subtotal,
                    includeVat = includeVat,
                    vatAmount = totals.vatAmount,
                    discountAmount = totals.discountApplied,
                    discountBeforeVat = discountBeforeVat,
                    grandTotal = totals.grandTotal
                )
            )
            emitMessage("แก้ไขใบเสร็จเรียบร้อย")
        }
    }

    fun deleteReceipt(id: String) {
        viewModelScope.launch {
            repository.deleteReceipt(id)
            emitMessage("ลบใบเสร็จแล้ว")
        }
    }

    // --- Menu 4: Meal Note ---
    fun updateMealsPerDay(mealsPerDay: Int) {
        val profile = uiState.value.activeProfile ?: return
        val clamped = mealsPerDay.coerceIn(1, 10)
        viewModelScope.launch {
            repository.updateProfile(profile.copy(mealsPerDay = clamped))
        }
    }

    fun importReceiptToMealNote(receiptUi: ReceiptUiModel) {
        val imported = receiptUi.items.map { item ->
            // Distribute receipt discount/VAT proportionally if needed, or use item's effective share
            val subtotal = receiptUi.items.sumOf { it.lineTotal }.coerceAtLeast(0.01)
            val ratio = if (receiptUi.entity.subtotal > 0.0) {
                receiptUi.entity.grandTotal / subtotal
            } else 1.0
            val effectiveCost = FormatUtils.roundThaiRetail(
                item.lineTotal * ratio,
                RoundingMode.NONE
            )
            MealIngredient(
                id = UUID.randomUUID().toString(),
                name = item.name,
                cost = effectiveCost,
                estimatedMeals = 2,
                sourceReceiptName = receiptUi.entity.storeName
            )
        }
        _workingMealIngredients.value = _workingMealIngredients.value + imported
        emitMessage("ดึงวัตถุดิบ ${imported.size} รายการจาก ${receiptUi.entity.storeName}")
    }

    fun addManualMealIngredient(name: String, cost: Double, estimatedMeals: Int) {
        val trimmed = name.trim()
        if (trimmed.isEmpty()) return
        val newItem = MealIngredient(
            id = UUID.randomUUID().toString(),
            name = trimmed,
            cost = max(0.0, cost),
            estimatedMeals = estimatedMeals.coerceAtLeast(1),
            sourceReceiptName = "เพิ่มเอง"
        )
        _workingMealIngredients.value = _workingMealIngredients.value + newItem
    }

    fun updateWorkingIngredientMeals(id: String, meals: Int) {
        val clamped = meals.coerceAtLeast(1)
        _workingMealIngredients.value = _workingMealIngredients.value.map {
            if (it.id == id) it.copy(estimatedMeals = clamped) else it
        }
    }

    fun removeWorkingIngredient(id: String) {
        _workingMealIngredients.value = _workingMealIngredients.value.filterNot { it.id == id }
    }

    fun clearWorkingIngredients() {
        _workingMealIngredients.value = emptyList()
    }

    fun setWholeSetMode(enabled: Boolean) {
        _useWholeSetMeals.value = enabled
    }

    fun setWholeSetMealsCount(count: Int) {
        _wholeSetMealsCount.value = count.coerceAtLeast(1)
    }

    fun saveMealPlanSummary(customTitle: String) {
        val profile = uiState.value.activeProfile ?: return
        val ingredients = _workingMealIngredients.value
        if (ingredients.isEmpty()) {
            emitMessage("กรุณาเพิ่มวัตถุดิบก่อนสรุปมื้ออาหาร")
            return
        }

        val totalCost = ingredients.sumOf { it.cost }
        val totalMeals = if (_useWholeSetMeals.value) {
            _wholeSetMealsCount.value.coerceAtLeast(1)
        } else {
            ingredients.sumOf { it.estimatedMeals }.coerceAtLeast(1)
        }
        val mealsPerDay = profile.mealsPerDay.coerceAtLeast(1)
        val estimatedDays = totalMeals.toDouble() / mealsPerDay.toDouble()
        val costPerMeal = totalCost / totalMeals.toDouble()

        val title = customTitle.trim().ifEmpty {
            val firstSource = ingredients.firstOrNull { it.sourceReceiptName.isNotBlank() }?.sourceReceiptName
            if (firstSource != null) {
                "ชุดวัตถุดิบ $firstSource (${FormatUtils.formatThaiDate(System.currentTimeMillis())})"
            } else {
                "สรุปมื้ออาหาร ${FormatUtils.formatThaiDate(System.currentTimeMillis())}"
            }
        }

        viewModelScope.launch {
            repository.insertMealPlan(
                MealPlanEntity(
                    id = UUID.randomUUID().toString(),
                    profileId = profile.id,
                    title = title,
                    mealsPerDay = mealsPerDay,
                    ingredientsJson = repository.encodeMealIngredients(ingredients),
                    totalCost = totalCost,
                    totalMeals = totalMeals,
                    estimatedDays = estimatedDays,
                    costPerMeal = costPerMeal
                )
            )
            _workingMealIngredients.value = emptyList()
            emitMessage("บันทึกการ์ดสรุปมื้ออาหารเรียบร้อย")
        }
    }

    fun deleteMealPlan(id: String) {
        viewModelScope.launch {
            repository.deleteMealPlan(id)
            emitMessage("ลบสรุปมื้ออาหารแล้ว")
        }
    }

    // --- Menu 5: Weekly Food ---
    fun setWeekStartDate(newStartMillis: Long) {
        val profileId = _activeProfileId.value ?: return
        val cleanStart = FormatUtils.startOfDayMillis(newStartMillis)
        val currentDays = uiState.value.activeWeekDays
        val updatedDays = (0..6).map { index ->
            val existing = currentDays.getOrNull(index)
            val newDate = FormatUtils.addDaysMillis(cleanStart, index)
            existing?.copy(dateMillis = newDate) ?: WeeklyDayRecord(dayIndex = index, dateMillis = newDate)
        }
        viewModelScope.launch {
            repository.upsertWeeklyActive(profileId, cleanStart, updatedDays)
        }
    }

    fun logWeeklyMealSlot(
        dayIndex: Int,
        slotType: MealSlotType,
        entry: WeeklyMealEntry
    ) {
        val profileId = _activeProfileId.value ?: return
        val startMillis = uiState.value.activeWeekStartMillis
        val currentDays = uiState.value.activeWeekDays.ifEmpty {
            repository.buildEmptyWeek(startMillis)
        }
        val updatedDays = currentDays.map { day ->
            if (day.dayIndex != dayIndex) day
            else when (slotType) {
                MealSlotType.MEAL_1 -> day.copy(meal1 = entry)
                MealSlotType.MEAL_2 -> day.copy(meal2 = entry)
                MealSlotType.SNACK -> day.copy(snack = entry)
            }
        }
        viewModelScope.launch {
            repository.upsertWeeklyActive(profileId, startMillis, updatedDays)
        }
    }

    fun saveCurrentWeekToHistory() {
        val profileId = _activeProfileId.value ?: return
        val startMillis = uiState.value.activeWeekStartMillis
        val days = uiState.value.activeWeekDays.ifEmpty {
            repository.buildEmptyWeek(startMillis)
        }
        val totalMeals = days.sumOf { it.loggedCount }
        if (totalMeals == 0) {
            emitMessage("ยังไม่มีรายการมื้ออาหารที่บันทึกในสัปดาห์นี้")
            return
        }
        val totalSpent = days.sumOf { it.dayTotal }
        val avgPerMeal = totalSpent / totalMeals.toDouble()
        val endMillis = FormatUtils.addDaysMillis(startMillis, 6)

        viewModelScope.launch {
            repository.saveWeeklyHistory(
                WeeklyHistoryEntity(
                    id = UUID.randomUUID().toString(),
                    profileId = profileId,
                    weekStartDateMillis = startMillis,
                    weekEndDateMillis = endMillis,
                    daysJson = repository.encodeWeeklyDays(days),
                    totalMealsCount = totalMeals,
                    totalSpent = totalSpent,
                    avgCostPerMeal = avgPerMeal
                )
            )
            // Reset active week to fresh 7 days starting next week or same start cleared
            val freshDays = repository.buildEmptyWeek(startMillis)
            repository.upsertWeeklyActive(profileId, startMillis, freshDays)
            emitMessage("บันทึกสรุปสัปดาห์เข้าสู่คลังประวัติแล้ว")
        }
    }

    fun deleteWeeklyHistory(id: String) {
        viewModelScope.launch {
            repository.deleteWeeklyHistory(id)
            emitMessage("ลบประวัติรายสัปดาห์แล้ว")
        }
    }

    companion object {
        fun calculateReceiptTotals(
            items: List<ReceiptLineItem>,
            includeVat: Boolean,
            discountAmount: Double,
            discountBeforeVat: Boolean
        ): ReceiptTotals {
            val subtotal = items.sumOf { it.lineTotal }
            val safeDiscount = max(0.0, discountAmount)
            val taxableBase: Double
            val vatAmount: Double
            val grandTotal: Double

            if (discountBeforeVat) {
                taxableBase = max(0.0, subtotal - safeDiscount)
                vatAmount = if (includeVat) taxableBase * 0.07 else 0.0
                grandTotal = taxableBase + vatAmount
            } else {
                taxableBase = subtotal
                vatAmount = if (includeVat) taxableBase * 0.07 else 0.0
                grandTotal = max(0.0, taxableBase + vatAmount - safeDiscount)
            }

            return ReceiptTotals(
                subtotal = subtotal,
                discountApplied = safeDiscount,
                taxableBase = taxableBase,
                vatAmount = vatAmount,
                grandTotal = grandTotal
            )
        }
    }
}

private data class Quad<A, B, C, D>(
    val first: A,
    val second: B,
    val third: C,
    val fourth: D
)

class MueLaViewModelFactory(
    private val repository: MueLaRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MueLaViewModel::class.java)) {
            return MueLaViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
