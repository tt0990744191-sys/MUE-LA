package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val MueLaLightColorScheme = lightColorScheme(
    primary = OliveGreen,
    onPrimary = SurfaceWhite,
    primaryContainer = SoftOliveBg,
    onPrimaryContainer = DeepOlive,
    secondary = DeepOlive,
    onSecondary = SurfaceWhite,
    secondaryContainer = SoftSage,
    onSecondaryContainer = CharcoalText,
    tertiary = VibrantOrange,
    onTertiary = SurfaceWhite,
    tertiaryContainer = SoftOrangeBg,
    onTertiaryContainer = VibrantOrange,
    background = MintBackground,
    onBackground = CharcoalText,
    surface = SurfaceWhite,
    onSurface = CharcoalText,
    surfaceVariant = SoftSage,
    onSurfaceVariant = MutedOliveText,
    outline = SageBorder,
    outlineVariant = SoftSage,
    error = VibrantOrange,
    onError = SurfaceWhite
)

private val MueLaShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun MueLaTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = MueLaLightColorScheme,
        typography = MueLaTypography,
        shapes = MueLaShapes,
        content = content
    )
}
