package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.MealSlotType
import com.example.data.model.WeeklyDayRecord
import com.example.data.model.WeeklyMealEntry
import com.example.ui.components.DashedReceiptDivider
import com.example.ui.components.MueLaLogo
import com.example.ui.theme.CharcoalText
import com.example.ui.theme.DeepOlive
import com.example.ui.theme.MintBackground
import com.example.ui.theme.MontserratFontFamily
import com.example.ui.theme.MutedOliveText
import com.example.ui.theme.OliveGreen
import com.example.ui.theme.PromptFontFamily
import com.example.ui.theme.SageBorder
import com.example.ui.theme.SoftOliveBg
import com.example.ui.theme.SoftOrangeBg
import com.example.ui.theme.SoftSage
import com.example.ui.theme.SurfaceWhite
import com.example.ui.theme.VibrantOrange
import com.example.ui.viewmodel.MealPlanUiModel
import com.example.ui.viewmodel.WeeklyHistoryUiModel
import com.example.util.FormatUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WeeklyFoodScreen(
    weekStartMillis: Long,
    weekDays: List<WeeklyDayRecord>,
    mealPlans: List<MealPlanUiModel>,
    weeklyHistory: List<WeeklyHistoryUiModel>,
    onChangeWeekStart: (Long) -> Unit,
    onLogMealSlot: (dayIndex: Int, slotType: MealSlotType, entry: WeeklyMealEntry) -> Unit,
    onSaveWeekToHistory: () -> Unit,
    onDeleteWeeklyHistory: (String) -> Unit
) {
    var selectedSubTab by remember { mutableIntStateOf(0) } // 0 = Active Week, 1 = History
    var showStartDatePicker by remember { mutableStateOf(false) }
    var editingSlot by remember { mutableStateOf<Pair<WeeklyDayRecord, MealSlotType>?>(null) }
    var viewingHistory by remember { mutableStateOf<WeeklyHistoryUiModel?>(null) }

    val todayMillis = remember { FormatUtils.startOfDayMillis() }
    val todayRecord = remember(weekDays, todayMillis) {
        weekDays.firstOrNull { it.dateMillis == todayMillis }
    }
    val todaySpent = todayRecord?.dayTotal ?: (weekDays.firstOrNull()?.dayTotal ?: 0.0)
    val todayLabel = if (todayRecord != null) "วันนี้กินไป" else "วันแรกของสัปดาห์"

    val totalWeekMeals = remember(weekDays) { weekDays.sumOf { it.loggedCount } }
    val totalWeekSpent = remember(weekDays) { weekDays.sumOf { it.dayTotal } }
    val avgPerMeal = remember(totalWeekSpent, totalWeekMeals) {
        if (totalWeekMeals == 0) 0.0 else totalWeekSpent / totalWeekMeals.toDouble()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MintBackground),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 640.dp)
        ) {
            TabRow(
                selectedTabIndex = selectedSubTab,
                containerColor = SurfaceWhite,
                contentColor = DeepOlive,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[selectedSubTab]),
                        color = OliveGreen
                    )
                }
            ) {
                Tab(
                    selected = selectedSubTab == 0,
                    onClick = { selectedSubTab = 0 },
                    text = {
                        Text(
                            "ตารางสัปดาห์นี้",
                            fontFamily = PromptFontFamily,
                            fontWeight = if (selectedSubTab == 0) FontWeight.SemiBold else FontWeight.Normal
                        )
                    },
                    modifier = Modifier.testTag("weekly_tab_active")
                )
                Tab(
                    selected = selectedSubTab == 1,
                    onClick = { selectedSubTab = 1 },
                    text = {
                        Text(
                            "คลังประวัติ (${weeklyHistory.size})",
                            fontFamily = PromptFontFamily,
                            fontWeight = if (selectedSubTab == 1) FontWeight.SemiBold else FontWeight.Normal
                        )
                    },
                    modifier = Modifier.testTag("weekly_tab_history")
                )
            }

            if (selectedSubTab == 0) {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    // Week Start Picker + Real-Time Summary
                    item(key = "weekly_summary_header") {
                        Card(
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                            border = BorderStroke(1.dp, SageBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = "สัปดาห์ 7 วัน",
                                            fontFamily = PromptFontFamily,
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = 15.sp,
                                            color = DeepOlive
                                        )
                                        Text(
                                            text = "${FormatUtils.formatThaiDate(weekStartMillis)} - ${FormatUtils.formatThaiDate(FormatUtils.addDaysMillis(weekStartMillis, 6))}",
                                            fontFamily = PromptFontFamily,
                                            fontSize = 12.sp,
                                            color = MutedOliveText
                                        )
                                    }
                                    OutlinedButton(
                                        onClick = { showStartDatePicker = true },
                                        shape = RoundedCornerShape(12.dp),
                                        border = BorderStroke(1.dp, OliveGreen),
                                        modifier = Modifier
                                            .height(48.dp)
                                            .testTag("pick_week_start_button")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.CalendarMonth,
                                            contentDescription = "เลือกวันเริ่มสัปดาห์",
                                            tint = DeepOlive,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "วันเริ่มต้น",
                                            fontFamily = PromptFontFamily,
                                            fontSize = 12.sp,
                                            color = DeepOlive
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    WeeklyStatChip(
                                        label = todayLabel,
                                        value = FormatUtils.formatBaht(todaySpent),
                                        modifier = Modifier.weight(1f)
                                    )
                                    WeeklyStatChip(
                                        label = "เฉลี่ยมื้อละ",
                                        value = FormatUtils.formatBaht(avgPerMeal),
                                        modifier = Modifier.weight(1f)
                                    )
                                    WeeklyStatChip(
                                        label = "สะสมสัปดาห์",
                                        value = FormatUtils.formatBaht(totalWeekSpent),
                                        highlight = true,
                                        modifier = Modifier.weight(1.1f)
                                    )
                                }
                            }
                        }
                    }

                    // 7-Day Table Cards
                    items(weekDays, key = { it.dayIndex }) { day ->
                        WeeklyDayCard(
                            day = day,
                            isToday = day.dateMillis == todayMillis,
                            onClickSlot = { slot -> editingSlot = day to slot }
                        )
                    }

                    // Save Week CTA
                    item(key = "save_week_cta") {
                        Button(
                            onClick = onSaveWeekToHistory,
                            colors = ButtonDefaults.buttonColors(containerColor = VibrantOrange),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp)
                                .testTag("save_week_history_button")
                        ) {
                            Icon(Icons.Filled.CheckCircle, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "บันทึกสัปดาห์นี้เข้าสู่คลังประวัติ",
                                fontFamily = PromptFontFamily,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 15.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                    }
                }
            } else {
                // Weekly History Archive
                if (weeklyHistory.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                modifier = Modifier
                                    .size(68.dp)
                                    .clip(CircleShape)
                                    .background(SoftOliveBg),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.History,
                                    contentDescription = null,
                                    tint = OliveGreen,
                                    modifier = Modifier.size(34.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "ยังไม่มีประวัติรายสัปดาห์",
                                fontFamily = PromptFontFamily,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 16.sp,
                                color = CharcoalText
                            )
                            Text(
                                text = "บันทึกการกินครบ 7 วันแล้วกด \"บันทึกสัปดาห์นี้\" เพื่อดูย้อนหลัง",
                                fontFamily = PromptFontFamily,
                                fontSize = 13.sp,
                                color = MutedOliveText
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(weeklyHistory, key = { it.entity.id }) { hist ->
                            Card(
                                shape = RoundedCornerShape(18.dp),
                                colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                                border = BorderStroke(1.dp, SageBorder),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(18.dp))
                                    .clickable { viewingHistory = hist }
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "${FormatUtils.formatThaiDayAndDate(hist.entity.weekStartDateMillis)} - ${FormatUtils.formatThaiDayAndDate(hist.entity.weekEndDateMillis)}",
                                            fontFamily = PromptFontFamily,
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = 15.sp,
                                            color = CharcoalText
                                        )
                                        Text(
                                            text = "กินทั้งหมด ${hist.entity.totalMealsCount} มื้อ · เฉลี่ย ${FormatUtils.formatBaht(hist.entity.avgCostPerMeal)}/มื้อ",
                                            fontFamily = PromptFontFamily,
                                            fontSize = 12.sp,
                                            color = MutedOliveText
                                        )
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text(
                                            text = FormatUtils.formatBaht(hist.entity.totalSpent),
                                            fontFamily = MontserratFontFamily,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 17.sp,
                                            color = VibrantOrange
                                        )
                                        IconButton(onClick = { onDeleteWeeklyHistory(hist.entity.id) }) {
                                            Icon(
                                                imageVector = Icons.Filled.DeleteOutline,
                                                contentDescription = "ลบประวัติสัปดาห์",
                                                tint = MutedOliveText,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showStartDatePicker) {
        val datePickerState = rememberDatePickerState(initialSelectedDateMillis = weekStartMillis)
        DatePickerDialog(
            onDismissRequest = { showStartDatePicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        datePickerState.selectedDateMillis?.let {
                            onChangeWeekStart(it)
                        }
                        showStartDatePicker = false
                    }
                ) {
                    Text("ตกลง", fontFamily = PromptFontFamily, color = DeepOlive)
                }
            },
            dismissButton = {
                TextButton(onClick = { showStartDatePicker = false }) {
                    Text("ยกเลิก", fontFamily = PromptFontFamily, color = MutedOliveText)
                }
            }
        ) {
            DatePicker(state = datePickerState)
        }
    }

    editingSlot?.let { (day, slotType) ->
        val currentEntry = when (slotType) {
            MealSlotType.MEAL_1 -> day.meal1
            MealSlotType.MEAL_2 -> day.meal2
            MealSlotType.SNACK -> day.snack
        }
        LogMealSlotDialog(
            dayDateLabel = FormatUtils.formatThaiDayAndDate(day.dateMillis),
            slotType = slotType,
            currentEntry = currentEntry,
            mealPlans = mealPlans,
            onDismiss = { editingSlot = null },
            onSave = { newEntry ->
                onLogMealSlot(day.dayIndex, slotType, newEntry)
                editingSlot = null
            }
        )
    }

    viewingHistory?.let { hist ->
        WeeklyHistoryReceiptDialog(
            history = hist,
            onDismiss = { viewingHistory = null }
        )
    }
}

@Composable
private fun WeeklyStatChip(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    highlight: Boolean = false
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = if (highlight) SoftOrangeBg else MintBackground,
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = label,
                fontFamily = PromptFontFamily,
                fontSize = 11.sp,
                color = MutedOliveText,
                maxLines = 1
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = value,
                fontFamily = MontserratFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = if (highlight) VibrantOrange else DeepOlive,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun WeeklyDayCard(
    day: WeeklyDayRecord,
    isToday: Boolean,
    onClickSlot: (MealSlotType) -> Unit
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
        border = BorderStroke(1.dp, if (isToday) OliveGreen else SageBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = FormatUtils.formatThaiDayAndDate(day.dateMillis),
                        fontFamily = PromptFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = if (isToday) DeepOlive else CharcoalText
                    )
                    if (isToday) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = SoftOliveBg
                        ) {
                            Text(
                                text = "วันนี้",
                                fontFamily = PromptFontFamily,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = DeepOlive,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
                Text(
                    text = FormatUtils.formatBaht(day.dayTotal),
                    fontFamily = MontserratFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = if (day.dayTotal > 0) VibrantOrange else MutedOliveText
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = SoftSage)
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MealSlotBox(
                    slotType = MealSlotType.MEAL_1,
                    entry = day.meal1,
                    onClick = { onClickSlot(MealSlotType.MEAL_1) },
                    modifier = Modifier.weight(1f)
                )
                MealSlotBox(
                    slotType = MealSlotType.MEAL_2,
                    entry = day.meal2,
                    onClick = { onClickSlot(MealSlotType.MEAL_2) },
                    modifier = Modifier.weight(1f)
                )
                MealSlotBox(
                    slotType = MealSlotType.SNACK,
                    entry = day.snack,
                    onClick = { onClickSlot(MealSlotType.SNACK) },
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun MealSlotBox(
    slotType: MealSlotType,
    entry: WeeklyMealEntry,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = if (entry.isLogged) SoftOliveBg else MintBackground,
        border = BorderStroke(
            width = 1.dp,
            color = if (entry.isLogged) OliveGreen.copy(alpha = 0.6f) else SageBorder
        ),
        modifier = modifier
            .height(74.dp)
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
    ) {
        Column(
            modifier = Modifier.padding(8.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = slotType.label,
                fontFamily = PromptFontFamily,
                fontSize = 10.sp,
                fontWeight = FontWeight.Medium,
                color = MutedOliveText
            )
            if (entry.isLogged) {
                Column {
                    Text(
                        text = entry.name.ifBlank { "มื้ออาหาร" },
                        fontFamily = PromptFontFamily,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 12.sp,
                        color = CharcoalText,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = FormatUtils.formatBaht(entry.cost),
                        fontFamily = MontserratFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = DeepOlive
                    )
                }
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.Add,
                        contentDescription = "บันทึก${slotType.label}",
                        tint = OliveGreen,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(2.dp))
                    Text(
                        text = "บันทึก",
                        fontFamily = PromptFontFamily,
                        fontSize = 12.sp,
                        color = OliveGreen
                    )
                }
            }
        }
    }
}

@Composable
private fun LogMealSlotDialog(
    dayDateLabel: String,
    slotType: MealSlotType,
    currentEntry: WeeklyMealEntry,
    mealPlans: List<MealPlanUiModel>,
    onDismiss: () -> Unit,
    onSave: (WeeklyMealEntry) -> Unit
) {
    var mode by remember { mutableIntStateOf(if (mealPlans.isNotEmpty() && !currentEntry.isLogged) 0 else 1) }
    var menuName by remember { mutableStateOf(currentEntry.name) }
    var costText by remember {
        mutableStateOf(
            if (currentEntry.cost > 0.0) FormatUtils.formatNumber(currentEntry.cost).replace(",", "") else ""
        )
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(22.dp),
            color = SurfaceWhite,
            border = BorderStroke(1.dp, SageBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "${slotType.label} · $dayDateLabel",
                            fontFamily = PromptFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = DeepOlive
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Filled.Close, contentDescription = "ปิด", tint = MutedOliveText)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = mode == 0,
                        onClick = { mode = 0 },
                        label = {
                            Text("ดึงจาก Meal Note", fontFamily = PromptFontFamily, fontSize = 12.sp)
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = OliveGreen,
                            selectedLabelColor = Color.White
                        )
                    )
                    FilterChip(
                        selected = mode == 1,
                        onClick = { mode = 1 },
                        label = {
                            Text("กรอกเอง", fontFamily = PromptFontFamily, fontSize = 12.sp)
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = OliveGreen,
                            selectedLabelColor = Color.White
                        )
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                if (mode == 0) {
                    if (mealPlans.isEmpty()) {
                        Text(
                            text = "ยังไม่มีการ์ดสรุปจาก Meal Note — สลับไปแท็บ \"กรอกเอง\" ได้ทันที",
                            fontFamily = PromptFontFamily,
                            fontSize = 13.sp,
                            color = MutedOliveText
                        )
                    } else {
                        Column(
                            modifier = Modifier
                                .height(220.dp)
                                .verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            mealPlans.forEach { plan ->
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = MintBackground,
                                    border = BorderStroke(1.dp, SageBorder),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .clickable {
                                            onSave(
                                                WeeklyMealEntry(
                                                    name = plan.entity.title,
                                                    cost = plan.entity.costPerMeal,
                                                    mealPlanTitle = plan.entity.title
                                                )
                                            )
                                        }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = plan.entity.title,
                                                fontFamily = PromptFontFamily,
                                                fontWeight = FontWeight.SemiBold,
                                                fontSize = 14.sp,
                                                color = CharcoalText,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Text(
                                                text = "${plan.entity.totalMeals} มื้อ",
                                                fontFamily = PromptFontFamily,
                                                fontSize = 11.sp,
                                                color = MutedOliveText
                                            )
                                        }
                                        Text(
                                            text = "${FormatUtils.formatBaht(plan.entity.costPerMeal)}/มื้อ",
                                            fontFamily = MontserratFontFamily,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = VibrantOrange
                                        )
                                    }
                                }
                            }
                        }
                    }
                } else {
                    OutlinedTextField(
                        value = menuName,
                        onValueChange = { menuName = it },
                        label = { Text("ชื่อเมนูอาหาร", fontFamily = PromptFontFamily) },
                        placeholder = { Text("เช่น ข้าวกะเพราไก่, กาแฟ", fontFamily = PromptFontFamily) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = costText,
                        onValueChange = { costText = it },
                        label = { Text("ราคา (บาท)", fontFamily = PromptFontFamily) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (currentEntry.isLogged) {
                            OutlinedButton(
                                onClick = { onSave(WeeklyMealEntry()) },
                                border = BorderStroke(1.dp, VibrantOrange),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                            ) {
                                Text("ล้างช่อง", fontFamily = PromptFontFamily, color = VibrantOrange)
                            }
                        }
                        Button(
                            onClick = {
                                val price = costText.toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0
                                val finalName = menuName.trim().ifEmpty { slotType.label }
                                onSave(WeeklyMealEntry(name = finalName, cost = price))
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = OliveGreen),
                            modifier = Modifier
                                .weight(1.5f)
                                .height(48.dp)
                        ) {
                            Text("บันทึกมื้อนี้", fontFamily = PromptFontFamily, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun WeeklyHistoryReceiptDialog(
    history: WeeklyHistoryUiModel,
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = SurfaceWhite,
            border = BorderStroke(1.dp, SageBorder),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .widthIn(max = 560.dp)
        ) {
            Column(
                modifier = Modifier
                    .verticalScroll(rememberScrollState())
                    .padding(18.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        MueLaLogo(size = 28.dp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "สรุปการกินรายสัปดาห์",
                            fontFamily = PromptFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = DeepOlive
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Filled.Close, contentDescription = "ปิด", tint = MutedOliveText)
                    }
                }

                Text(
                    text = "${FormatUtils.formatThaiDate(history.entity.weekStartDateMillis)} - ${FormatUtils.formatThaiDate(history.entity.weekEndDateMillis)}",
                    fontFamily = PromptFontFamily,
                    fontSize = 13.sp,
                    color = MutedOliveText
                )

                Spacer(modifier = Modifier.height(12.dp))
                DashedReceiptDivider()
                Spacer(modifier = Modifier.height(10.dp))

                history.days.forEach { day ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = FormatUtils.formatThaiDayAndDate(day.dateMillis),
                                fontFamily = PromptFontFamily,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 13.sp,
                                color = CharcoalText
                            )
                            val mealsText = listOfNotNull(
                                day.meal1.takeIf { it.isLogged }?.let { "${it.name} (${FormatUtils.formatBaht(it.cost)})" },
                                day.meal2.takeIf { it.isLogged }?.let { "${it.name} (${FormatUtils.formatBaht(it.cost)})" },
                                day.snack.takeIf { it.isLogged }?.let { "${it.name} (${FormatUtils.formatBaht(it.cost)})" }
                            ).joinToString(" · ")
                            Text(
                                text = mealsText.ifEmpty { "ไม่มีรายการบันทึก" },
                                fontFamily = PromptFontFamily,
                                fontSize = 11.sp,
                                color = MutedOliveText
                            )
                        }
                        Text(
                            text = FormatUtils.formatBaht(day.dayTotal),
                            fontFamily = MontserratFontFamily,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp,
                            color = DeepOlive
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                DashedReceiptDivider()
                Spacer(modifier = Modifier.height(10.dp))

                ReceiptSummaryLine("จำนวนมื้อทั้งหมด", "${history.entity.totalMealsCount} มื้อ")
                ReceiptSummaryLine("เฉลี่ยมื้อละ", FormatUtils.formatBaht(history.entity.avgCostPerMeal))

                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = SoftOrangeBg,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "ยอดรวมทั้งสัปดาห์",
                            fontFamily = PromptFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = CharcoalText
                        )
                        Text(
                            text = FormatUtils.formatBaht(history.entity.totalSpent),
                            fontFamily = MontserratFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp,
                            color = VibrantOrange
                        )
                    }
                }
            }
        }
    }
}
