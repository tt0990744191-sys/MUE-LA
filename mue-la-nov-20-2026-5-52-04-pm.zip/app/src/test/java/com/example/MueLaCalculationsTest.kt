package com.example

import com.example.data.model.ReceiptLineItem
import com.example.data.model.RoundingMode
import com.example.ui.viewmodel.MueLaViewModel
import com.example.util.FormatUtils
import org.junit.Assert.assertEquals
import org.junit.Test

class MueLaCalculationsTest {

    @Test
    fun testWeightedThaiRetailRounding() {
        // 0.45 * 189.0 = 85.05
        assertEquals(85.05, FormatUtils.roundThaiRetail(85.05, RoundingMode.NONE), 0.001)
        assertEquals(85.00, FormatUtils.roundThaiRetail(85.05, RoundingMode.QUARTER_25), 0.001)
        assertEquals(85.00, FormatUtils.roundThaiRetail(85.05, RoundingMode.WHOLE_BAHT), 0.001)

        // 85.18 -> nearest 0.25 is 85.25, nearest whole is 85.00
        assertEquals(85.25, FormatUtils.roundThaiRetail(85.18, RoundingMode.QUARTER_25), 0.001)
        assertEquals(85.00, FormatUtils.roundThaiRetail(85.18, RoundingMode.WHOLE_BAHT), 0.001)

        // 85.62 -> nearest 0.25 is 85.50, nearest whole is 86.00
        assertEquals(85.50, FormatUtils.roundThaiRetail(85.62, RoundingMode.QUARTER_25), 0.001)
        assertEquals(86.00, FormatUtils.roundThaiRetail(85.62, RoundingMode.WHOLE_BAHT), 0.001)
    }

    @Test
    fun testReceiptTotalsVatAndDiscount() {
        val items = listOf(
            ReceiptLineItem(
                id = "1",
                name = "อกไก่",
                category = "อาหารสด",
                unit = "กิโลกรัม",
                quantity = 1.0,
                unitPrice = 200.0
            ),
            ReceiptLineItem(
                id = "2",
                name = "ผักสด",
                category = "อาหารสด",
                unit = "แพ็ก",
                quantity = 2.0,
                unitPrice = 50.0
            )
        )
        // Subtotal = 300.0, Discount = 50.0, Before VAT => base 250.0, VAT = 17.5, total = 267.5
        val beforeVat = MueLaViewModel.calculateReceiptTotals(
            items = items,
            includeVat = true,
            discountAmount = 50.0,
            discountBeforeVat = true
        )
        assertEquals(300.0, beforeVat.subtotal, 0.001)
        assertEquals(250.0, beforeVat.taxableBase, 0.001)
        assertEquals(17.5, beforeVat.vatAmount, 0.001)
        assertEquals(267.5, beforeVat.grandTotal, 0.001)

        // Discount After VAT => base 300.0, VAT = 21.0, total = 321.0 - 50.0 = 271.0
        val afterVat = MueLaViewModel.calculateReceiptTotals(
            items = items,
            includeVat = true,
            discountAmount = 50.0,
            discountBeforeVat = false
        )
        assertEquals(300.0, afterVat.taxableBase, 0.001)
        assertEquals(21.0, afterVat.vatAmount, 0.001)
        assertEquals(271.0, afterVat.grandTotal, 0.001)
    }
}
